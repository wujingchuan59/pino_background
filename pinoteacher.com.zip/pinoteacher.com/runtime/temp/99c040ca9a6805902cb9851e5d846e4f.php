<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"/Users/mac/Movies/Work/pinosearch.com/public/../application/admin/view/usersetup/index.html";i:1528299141;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name=”viewport” content=”width=device-width, initial-scale=1″ />

    <title>PINO用户设置</title>
    <!--属性设置-->

    <style type="text/css">

        *{
            padding: 0;
            margin: 0;
        }

        #head{
            font-size: 40px;
            color: #4A90E2;
            margin-left: 20%;
            margin-top: 30px;

        }
        #head:visited{
            text-decoration: none;
        }
        #head:hover{
            text-decoration: none;
        }
        #head:active{
            text-decoration: none;
        }
        #head:link{
            text-decoration: none;
        }

        #image{
            margin-top: auto;
            float: right;
            margin-right: 10%;
        }

        .user-info{
            font-size: 20px;
            margin-left: 10.5%;
            color: #636c72;
        }
        .user-text{
            width: 300px;
        }

        #user-name{
            margin-top: 2%;
        }

        #name-text{
            margin-top: 2%;
            font-size: 15px;
            line-height: 20px;
        }

        #user-qq{
            margin-top: 3%;
        }

        #qq-text{
            margin-top: 1%;
            font-size: 15px;
            line-height: 20px;
        }

        #user-password{
            margin-top: 1%;
        }

        #password-text{
            margin-top: 1%;
            font-size: 15px;
            line-height: 20px;
        }

        #user-category{
            margin-top: 1%;
        }

        #user-can-solve{
            margin-top: 1%;
        }

        #submit{
            margin-left: 10%;
            margin-top: 20px;
            color: white;
            font-size: 20px;
            font-weight: bolder;
            border-width: 0;
            background-color: #4A90E2;
            width: 400px;
            height: 50px;
        }

        #can-solve-text-area{
            font-size: smaller;
            width: 30%;
            height: 150px;
        }


    </style>

</head>
<body>

<!--head-->
<div id="head-div">
    <div>
        <a id="head" href="<?php echo url('admin/index/index'); ?>">PINO | 用户设置 (<?php echo $phone; ?>)</a>
        <img id="image" src="http://p5ml11w5w.bkt.clouddn.com/advertise.png"/>
    </div>
</div>

<!--body-->
<div class="user-info" id="body-div">
    <form action="<?php echo url('admin/usersetup/updateUserInfo'); ?>" method="post" name="register-name">
        <label class="user-info">
            Rating:
        </label>
        <label id="rating-rank-value"><?php echo $rate; ?></label>
        <br>
        <label class="user-info">
            当前余额:
        </label><label id="money-left-value"><?php echo $money_left; ?></label>
        <label>
            RMB
        </label>
        <br>
        <label class="user-info">
            当前收入:
        </label>
        <label id="income-value"><?php echo $income; ?></label>
        <label>
            RMB
        </label>
        <br>
        <label class="user-info" id="user-name">用户名</label>
        <input class="user-text" id="name-text" placeholder="请设置用户名" type="text" name="username" required/>
        <br>
        <br>
        <label class="user-info" id="user-qq">QQ号</label>
        <input class="user-text" id="qq-text" placeholder="请设置qq账号" type="text" name="qq" required/>
        <br>
        <br>

        <label class="user-info" id="user-password">新密码</label>
        <input class="user-text" id="password-text" placeholder="请设置登录密码" type="password" name="password" required/>
        <br>
        <br>
        <label class="user-info" id="user-category">类别为</label>
        <select name="category" class="category" required>
            <?php if(is_array($categories) || $categories instanceof \think\Collection || $categories instanceof \think\Paginator): $i = 0; $__LIST__ = $categories;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <option value="<?php echo $key; ?>"><?php echo $vo; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <br>
        <br>
        <label class="user-info" id="user-can-solve">可解决问题</label>
        <br>
        <textarea id="can-solve-text-area" class="user-info" name="can_solve" rows="3" cols="35" placeholder="请详细描述您所擅长领域的关键词,如托福阅读,PHP加载。同时,描述可以解决的问题,如托福某某文章或C++重载技术等." required></textarea>
        <br>
        <br>
        <button id="submit" onclick="">更新信息</button>

    </form>
</div>

<!--footer-->
<div id="footer-div">

</div>


</body>
</html>