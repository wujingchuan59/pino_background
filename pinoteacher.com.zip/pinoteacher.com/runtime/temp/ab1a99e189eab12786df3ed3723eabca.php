<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"/Users/mac/Movies/Work/pinosearch.com/public/../application/admin/view/more/index.html";i:1528112103;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">

    <title>大神们在解决什么问题</title>

    <style type="text/css">

        #head-div{
            width: 90%;
            height: 15%;
            margin-left: 5%;
            //background-color: #1d1e1f;
        }

        #category-div{
            width: 80%;
            height: 10%;
            margin-top: 2%;
            margin-left: 10%;
        }

        #head{
            color: #4A90E2;
            font: normal 100% Helvetica, Arial, sans-serif;
            margin-left: 10%;
            width: 10%;
            font-size: xx-large;
            font-weight: bolder;
        }

        #head:visited{
            text-decoration: none;
        }
        #head:hover{
            text-decoration: none;
        }
        #head:active{
            text-decoration: none;
        }
        #head:link{
            text-decoration: none;
        }

        #search-text{

            line-height: 30px;
            margin-left: 5%;
            width: 40%;
            border-color: #4A90E2;
            border-style: solid;

        }

        #more-search-button{

            line-height: 30px;
            border: none;
            background-color: #4A90E2;
            color: white;
            font: normal 100% Helvetica, Arial, sans-serif;
            width: 10%;
            font-size: larger;
            margin-left: 0;

        }

        #head-content-line{

            color: #4A90E2;

        }

        #content-div{

            margin-left: 5%;
            width: 90%;

        }

        #question_content-div{

            margin-left: 10%;
            width: 80%;

        }

        .problem-solved-content{

            font-size: larger;
            font-weight: bolder;

        }

        .problem-solver-name-label{

            font-family: "Avenir Next";
            color: #999999;
            font-size: small;

        }

        .problem-solver-date{

            font-family: "Avenir Next";
            color: #999999;
            font-size: small;

        }

        #footer-div{

            width: 100%;
            height: 100px;
            margin-left: 0;
            background-color: #4A90E2;
            margin-top: 5%;
        }

        #rights-reserved{
            color: white;
            width: 40%;
            margin-left: 30%;
            margin-top: 5%;
        }

        #footer-company-label{
            width: 70%;
            margin-left: 15%;
            text-align: center;
            font-size: x-large;
        }

        #footer-icp-label{
            width: 60%;
            margin-left: 30%;
            text-align: center;
        }


    </style>

</head>
<!--head-->
<div class="head" id="head-div">
    <div>
        <a id="head" href="<?php echo url('admin/index/index'); ?>">PINO一下,老师就来</a>
            <input id="search-text" type="search" placeholder="请输入您需要搜索的问题?"/>
            <button id="more-search-button"> P I N O </button>
    </div>
    <div class="body" id="category-div">
        <form id="category-form" action="<?php echo url('more/search'); ?>">


        </form>

    </div>
    <div>
        <hr id="head-content-line">
    </div>
</div>
<!--body-->

<div class="content-body" id="content-div">

    <?php if(is_array($teachersInfo) || $teachersInfo instanceof \think\Collection || $teachersInfo instanceof \think\Paginator): $i = 0; $__LIST__ = $teachersInfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

        <div id="question_content-div">
            <label class="problem-solved-content">PHP如何实现在.php文件和.js文件之间的传值<?php echo $vo['question_solved']; ?></label>
            <label id="rate">5.0</label><label id="rate-label">好评</label>
            <br>
            <br>
            <label class="problem-solver-name-label">姓名(称呼):&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label><label class="problem-solver-name-label"><?php echo $vo['username']; ?></label>
            <br>
            <label class="problem-solver-name-label">联系方式:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label><label class="problem-solver-name-label"><?php echo $vo['phone']; ?></label>
            <br>
            <label class="problem-solver-date">解决日期:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label><label class="problem-solver-date">2018年6月4日</label>
            <br>
            <hr id="space-line">
        </div>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<!--footer-->
<div class="footer" id="footer-div">
   <div id="rights-reserved">
       <div>
           <br>
           <label id="footer-company-label">
               北京匹诺曹与他的朋友们网络科技有限公司
           </label>
       </div>
       <div>
           <br>
           <label id="footer-icp-label">
               ©2018 PinoTech京ICP证17059422号
           </label>
       </div>
   </div>
</div>
<body>

</body>
</html>