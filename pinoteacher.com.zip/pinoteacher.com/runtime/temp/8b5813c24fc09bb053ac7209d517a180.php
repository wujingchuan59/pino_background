<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:89:"/Users/mac/Movies/Work/pinoteacher.com/public/../application/admin/view/result/index.html";i:1531788412;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
	<title> Pino 搜索结果 </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Tuition Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<link href="/static/hadmin/static/result/css/bootstrap.css" rel='stylesheet' type='text/css' />
	<!-- Custom Theme files -->
	<link href="/static/hadmin/static/result/css/style.css" rel='stylesheet' type='text/css' />
	<link href="/static/hadmin/static/result/css/swipebox.css" rel='stylesheet' type='text/css' />
	<script src="/static/hadmin/static/result/js/jquery-1.11.1.min.js"></script>
	<script src="/static/hadmin/static/result/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/static/hadmin/static/result/js/move-top.js"></script>
	<script type="text/javascript" src="/static/hadmin/static/result/js/easing.js"></script>
	<link href='https://fonts.googleapis.com/ css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
	<!--/script-->
	<script src="/static/hadmin/static/result/js/modernizr.custom.97074.js"></script>

	<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
			});
		});
	</script>
	<!--script-->
	<script src="/static/hadmin/static/result/js/jquery.swipebox.min.js"></script>
	<script type="text/javascript">
		jQuery(function($) {
			$(".swipebox").swipebox();
		});

	</script>

	<style type="text/css">

		*{
			background-color: #92C9D9;

		}

		.banner-top {

			margin-top: 0;
			width: 100%;
			height: 100%;
			position: absolute;
			right: 50%;
			margin-right: -50%;

		}

		.banner{

			background: none;
			height: 75%;

		}

		.banner .banner-top .header{
			color: #00BCFF;
		}

		@media (max-width: 1024px) {
			.banner .banner-top .header{
				color: #00BCFF;
				margin-top: 100px;
				font-size: 30px;
			}

			.banner-top {

				margin-top: 0;
				width: 60%;
				position: absolute;
				right: 50%;
				margin-right: -30%;

			}

		}

		@media (max-width: 414px) {
			.banner .banner-top .header{
				color: #00BCFF;
				margin-top: 20px;
				font-size: 30px;
			}

			.banner-top {

				margin-top: 0;
				width: 90%;
				position: absolute;
				right: 50%;
				margin-right: -45%;

			}

		}

		@media (max-width:384px) {
			.banner .banner-top .header{
				color: #00BCFF;
				margin-top: 20px;
				font-size: 30px;
			}

			.banner-top {

				margin-top: 0;
				width: 90%;
				position: absolute;
				right: 50%;
				margin-right: -45%;

			}

		}

		@media (max-width: 320px) {

			.banner .banner-top .header{
				color: #00BCFF;
				margin-top: 20px;
				font-size: 30px;
			}

			.banner-top {

				margin-top: 0;
				width: 90%;
				position: absolute;
				right: 50%;
				margin-right: -45%;

			}


		}



	</style>
</head>
<body onload="bodyOnLoad()">
<!--header-->
<!--banner-->
<div class="banner">
	<div class="banner-top">
		<h3 class="header"> Pino 一 下 , 老 师 就 来 </h3>
		<br>
		<br>
		<br>
		<br>
		<div class="content">
			<div class="body-div">
				<div class="body-content">
					<label class="body-label" href="#"><?php echo $prefix; ?><?php echo $teachers_found; ?><?php echo $suffix; ?><br></label>
					<button class="body-more-button" onclick="javascript:history.go(-1);">再找更多...</button>
					<br>
					<button class="body-solve-problem-button" onclick="gotoSolveProblem()">了解详细</button>
				</div>
			</div>
		</div>
		<div>
		</div>
	</div>

	<!--//contact-->

	<!--start-smooth-scrolling-->
	<script type="text/javascript">

		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
	</script>
	<!--start-smoth-scrolling-->
	<script type="text/javascript">

		$(document).ready(function() {
			/*
			 var defaults = {
			 containerID: 'toTop', // fading element id
			 containerHoverID: 'toTopHover', // fading element hover id
			 scrollSpeed: 1200,
			 easingType: 'linear'
			 };
			 */

			$().UItoTop({ easingType: 'easeOutQuart' });

		});
	</script>

</body>
</html>