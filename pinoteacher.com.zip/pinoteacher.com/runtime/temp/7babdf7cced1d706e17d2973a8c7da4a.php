<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"/Users/mac/Movies/Work/pinosearch.com/public/../application/admin/view/index/index.html";i:1528274424;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=2.0, user-scalable=yes">
    <script type="text/javascript" src="https://www.imooc.com/static/lib/jquery/1.9.1/jquery.js"></script>
    <title>Pino一下,老师就来</title>

    <!--Style-->
    <style type="text/css">

        *{
            padding: 0;
            margin: 0;
        }

        body {
            font: normal 100% Helvetica, Arial, sans-serif;
        }

        .user:link{
            color: #4A90E2;
        }
        .user{
            width: 3%;
            height: 20px;
            margin-top: 1%;
            border-width: 0;
            color:#4A90E2;
            font-size: 1.1em;
            background-color: white;
            white-space: nowrap;
        }
        #register{
            margin-left: 0.5%;
            text-overflow:ellipsis;
        }

        #login{
            margin-left: 0.5%;
            text-overflow:ellipsis;

        }

        #userSetup{
            margin-left: 0.5%;
            text-overflow:ellipsis;

        }

        #logo-text{
            width: 50%;
            background-color: white;
            margin-left: 28%;
            margin-top: 10%;
            margin-bottom: 2%;
            color: #4A90E2;
            font-size: 3.5em;
            white-space: nowrap;
        }

        #search{

            width: 50%;
            height: 2.2em;
            margin-left: 22%;
            font-size: 1.0em;
            white-space: nowrap;
        }

        #start{

            height: 32px;
            width: 5.5em;
            margin-left: 1%;
            border-color: white;
            background-color: dodgerblue;
            color:white;
            font-size: 1.0em;
            border-radius: 8px;
            white-space: nowrap;
        }

        #QR-code{
            margin-top:22%;
            margin-left: 46%;
            width: 5%;
            height: 5%;
            white-space: nowrap;
        }

        #QR-text{
            margin-top:0;
            margin-left: 37.4%;
            width: 25%;
            height: 20px;
            color: #4A90E2;
            white-space: nowrap;
        }

        #rights-reserved{
            margin-top: 2%;
            margin-left:40%;
            color:#999999;
            white-space: nowrap;
        }

    </style>

</head>

<body onload="bodyOnload()">
<!--Head-->
<div class="head">
    <button type="submit" id="register" class="user" onclick="register()">注册</button>
    <button type="submit" id="login" class="user" onclick="login()">登录</button>
    <button type="submit" id="userSetup" class="user" onclick="userSetup()"><?php echo $phone; ?></button>

</div>

<!--Body-->
<div class="body">
    <form class="main form" name="search" action="<?php echo url('index/sendMessage'); ?>" method="post" onsubmit="return typeContact()">
        <div>
            <div id="logo-text">Pino 一 下 , 老 师 就 来 </div>
            <input type="text" name="searchContent" id="search" autocomplete="OFF" placeholder="您可以这么问,这个题目为什么不选A?/如何准备留学文书?/为啥我单身30年?" required/>
            <input type="text" name="contact" id="contactInfo" hidden autocomplete="OFF" placeholder="您可以这么问,这个题目为什么不选A?/如何准备留学文书?" />
            <input type="submit" value="  P I N O "  id="start"/>
        </div>
    </form>

</div>

<!--Footer-->
<div class="footer">
    <!--QR Code-->
    <div>
        <img id="QR-code" src="http://p5ml11w5w.bkt.clouddn.com/QR-Code.jpg">
        <div id="QR-text">关注匹诺曹官方公众号,报名大小机构都有补贴哦</div>
    </div>

    <!--Reserved Rights-->
    <div id="rights-reserved">©2018 PinoTech京ICP证17059422号 </div>

</div>

<!--跳转-->
<script type="text/javascript">

    function bodyOnload() {


    }

    function register() {
       window.location.href="admin/register";
    }

    function login() {
        window.location.href="admin/login";
    }

    function typeContact() {

        var value = window.prompt("填写联系方式,老师马上来帮你?(建议填写QQ或微信账号)");
        document.getElementById("contactInfo").setAttribute("value",value);

    }
    
    function userSetup() {

        window.location.href="admin/usersetup";

    }
    

</script>


</body>
</html>