<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"/Users/mac/Movies/Work/pinoteacher.com/public/../application/admin/view/index/index.html";i:1545377911;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <title>有难事儿,PINO一下</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Tuition Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="/static/hadmin/static/index/css/bootstrap.css" rel='stylesheet' type='text/css' />
    <!-- Custom Theme files -->
    <link href="/static/hadmin/static/index/css/style.css" rel='stylesheet' type='text/css' />
    <link href="/static/hadmin/static/index/css/swipebox.css" rel='stylesheet' type='text/css' />
    <script src="/static/hadmin/static/index/js/jquery-1.11.1.min.js"></script>
    <script src="/static/hadmin/static/index/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/index/js/move-top.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/index/js/easing.js"></script>
    <link href='https://fonts.googleapis.com/ css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
    <!--/script-->
    <script src="/static/hadmin/static/index/js/modernizr.custom.97074.js"></script>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},900);
            });
        });
    </script>
    <!--script-->
    <script src="/static/hadmin/static/index/js/jquery.swipebox.min.js"></script>
    <script type="text/javascript">
        jQuery(function($) {
            $(".swipebox").swipebox();
        });

    </script>

    <style type="text/css">

        .header-section .header-top{
            height: 15px;
            background: none;
            padding-top: 2px;
            padding-bottom: 2px;

        }
        .banner .banner-top .header{

            color: #00BCFF;
            font-size: 50px;
            line-height: 60px;

        }
        .header-section .header-top .container{

            margin-left: 50px;
            margin-top: 1px;

        }

        .header-section .header-top .container .inner-head{

            width: 50%;
            margin-left: -50px;
            padding-top: 2px;

        }

        .banner{

            background: none;
            height: 75%;

        }

        .banner .banner-top{

            width: 100%;
            text-align: center;
            position: absolute;
            top: 0;
            right: 50%;
            margin-right: -50%;

        }

        .banner .banner-top .search-content{

            width: 100%;
            height: 30px;
            margin-top: 5%;
            position: absolute;
            right: 50%;
            margin-right: -50%;

        }

        .banner .banner-top .search-content .search{

            display: inline-block;
            width: 50%;
            height: 40px;
            line-height: 19px;
            position: absolute;
            top: 0;
            right: 50%;
            margin-right: -25%;

        }

        .banner .banner-top .search-content .start{

            width: 10%;
            height: 40px;
            margin: 0;
            line-height: 19px;
            font-size: 15px;
            text-align: center;
            background-color: #00BCFF;
            position: absolute;
            right: 15%;
            top: 0;

        }

        .copy{
            background-color: white;
        }
        .copy .copyright{
            color: #4b5257;
        }

        .copy .copyright .QR-code{

            height: 80px;
            width: 80px;

        }
        @media (max-width:1024px){
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 60px;
                margin-top: 200px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 50px;
                font-size: 20px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 50px;
                font-size: 20px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 50px;
                font-size: 20px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 72%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
            .copy .copyright .QR-code{

                height: 80px;
                width: 80px;

            }
        }
        @media (max-width:991px){
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
        }
        @media (max-width:800px){
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
        }
        @media (max-width:768px) {
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 50px;
                margin-top: 150px;
                font-weight: bolder;
            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 70%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
        }
        @media (max-width:736px){
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }

        }
        @media (max-width:667px){
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }

        }
        @media (max-width:640px) {
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
        }

        @media (max-width:600px) {
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
        }

        @media (max-width:568px){
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }

        }
        @media (max-width:480px){

            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 20px;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 60%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
        }
        @media (max-width: 414px) {

            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 35px;
                margin-top: 100px;
                font-weight: bolder;

            }

            .header-section .header-top .container .inner-head .mail{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location{

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 76%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
            .copy{
                background-color: white;
                margin-top: 300px;
            }

        }

        @media (max-width:384px) {
            .banner .banner-top .header{

                color: #00BCFF;
                font-size: 30px;

            }

            .header-section .header-top .container .inner-head .mail {

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .phone {

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .header-section .header-top .container .inner-head .location {

                color: #00BCFF;
                float: left;
                width: 30px;
                font-size: 10px;
                margin-left: 2px;
                margin-top: 0;

            }

            .banner .banner-top .search-content .search {

                width: 73%;
                height: 30px;
                position: absolute;
                top: 0;
                right: 50%;
                font-size: 10px;
                margin-right: -30%;

            }

            .banner .banner-top .search-content .start {

                height: 30px;
                padding-left: 3px;;
                padding-right: 3px;
                width: 15%;
                font-size: 10px;
                text-align: center;
                position: absolute;
                margin-left: 1px;
                right: 5%;
                top: 0;
            }
            .copy{
                background-color: white;
                margin-top: 300px;
            }
            @media (max-width:361px) {
                .banner .banner-top .header{

                    color: #00BCFF;
                    font-size: 30px;

                }

                .header-section .header-top .container .inner-head .mail {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-top: 0;

                }

                .header-section .header-top .container .inner-head .phone {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-left: 2px;
                    margin-top: 0;

                }

                .header-section .header-top .container .inner-head .location {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-left: 2px;
                    margin-top: 0;

                }

                .banner .banner-top .search-content .search {

                    width: 73%;
                    height: 30px;
                    position: absolute;
                    top: 0;
                    right: 50%;
                    font-size: 10px;
                    margin-right: -30%;

                }

                .banner .banner-top .search-content .start {

                    height: 30px;
                    padding-left: 3px;;
                    padding-right: 3px;
                    width: 15%;
                    font-size: 10px;
                    text-align: center;
                    position: absolute;
                    margin-left: 1px;
                    right: 5%;
                    top: 0;
                }
                .copy{
                    background-color: white;
                    margin-top: 180px;
                }
            @media (max-width:376px) {
                .banner .banner-top .header{

                    color: #00BCFF;
                    font-size: 30px;
                    font-weight: bolder;

                }

                .header-section .header-top .container .inner-head .mail {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-top: 0;

                }

                .header-section .header-top .container .inner-head .phone {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-left: 2px;
                    margin-top: 0;

                }

                .header-section .header-top .container .inner-head .location {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-left: 2px;
                    margin-top: 0;

                }

                .banner .banner-top .search-content .search {

                    width: 73%;
                    height: 30px;
                    position: absolute;
                    top: 0;
                    right: 50%;
                    font-size: 10px;
                    margin-right: -30%;

                }

                .banner .banner-top .search-content .start {

                    height: 30px;
                    padding-left: 3px;;
                    padding-right: 3px;
                    width: 15%;
                    font-size: 10px;
                    text-align: center;
                    position: absolute;
                    margin-left: 1px;
                    right: 5%;
                    top: 0;
                }
                .copy{
                    background-color: white;
                    margin-top: 380px;
                }

            @media (max-width: 320px) {

                .banner .banner-top .header{

                    color: #00BCFF;
                    font-size: 25px;
                    font-weight: bolder;

                }

                .header-section .header-top .container .inner-head .mail {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-top: 0;

                }

                .header-section .header-top .container .inner-head .phone {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-left: 2px;
                    margin-top: 0;

                }

                .header-section .header-top .container .inner-head .location {

                    color: #00BCFF;
                    float: left;
                    width: 30px;
                    font-size: 10px;
                    margin-left: 2px;
                    margin-top: 0;

                }

                .banner .banner-top .search-content .search {

                    width: 75%;
                    height: 30px;
                    position: absolute;
                    top: 0;
                    right: 50%;
                    font-size: 10px;
                    margin-right: -30%;

                }

                .banner .banner-top .search-content .start {

                    height: 30px;
                    padding-left: 3px;;
                    padding-right: 3px;
                    width: 15%;
                    font-size: 10px;
                    text-align: center;
                    position: absolute;
                    margin-left: 1px;
                    right: 5%;
                    top: 0;
                }
                .copy{
                    background-color: white;
                    margin-top: 220px;
                }

            }

        }


    </style>
</head>
<body onload="bodyOnLoad()">
<!--header-->
<ul class="side_nav">
</ul>

<div class="header-section" id="home">
    <div class="header-top">
        <div class="container">
            <div class="inner-head">
                <p class="col-md-4 mail" onclick="register()"> 注册 </p>
                <p class="col-md-4 phone" onclick="login()"> 登录 </p>
                <p class="col-md-4 location" onclick="userSetup()"> <?php echo $phone; ?> </p>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <!--logo-->
</div>
<!--banner-->
<div class="banner">
    <div class="banner-top">
        <h3 class="header">有 难 事 儿, PINO 一 下</h3>
        <div class="search-content">
            <form class="main form" id="submit-form" name="search" action="<?php echo url('index/search'); ?>" method="post" onsubmit="return check()">
                <input style="display: inline-block" type="text" name="searchContent" class="search" placeholder="您需要找什么样人或解决什么难题?" required/>
                <input type="submit" value=" P I N O "  class="start" onclick="typeContact()"/>
            </form>
        </div>
    </div>
</div>

<!--//contact-->
<div class="copy">
    <p class="copyright">
        <img class="QR-code" src="http://pj0j5uums.bkt.clouddn.com/%E5%85%AC%E4%BC%97%E5%8F%B7%E4%BA%8C%E7%BB%B4%E7%A0%81@2x.png">
        <br>
        关注PINO搜索官方公众号,有惊喜哦
        <br>
        Copyright &copy; 2018. All rights reserved.
        <br>
        京ICP证17059422号
    </p>
</div>
<!--start-smooth-scrolling-->
<script type="text/javascript">

    jQuery(document).ready(function($) {
        $(".scroll").click(function(event){
            event.preventDefault();
            $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
        });
    });
</script>
<!--start-smoth-scrolling-->
<script type="text/javascript">
    function bodyOnLoad() {

        var contactInfo = document.getElementById("contactInfo");
        contactInfo.style.display = "none";

    }

    function register() {
        window.location.href="admin/register";
    }

    function login() {
        window.location.href="admin/login";
    }

    function typeContact() {

    }

    function userSetup() {

        window.location.href="admin/usersetup";

    }

    $(document).ready(function() {
        /*
         var defaults = {
         containerID: 'toTop', // fading element id
         containerHoverID: 'toTopHover', // fading element hover id
         scrollSpeed: 1200,
         easingType: 'linear'
         };
         */

        $().UItoTop({ easingType: 'easeOutQuart' });

    });
</script>
</body>
</html>