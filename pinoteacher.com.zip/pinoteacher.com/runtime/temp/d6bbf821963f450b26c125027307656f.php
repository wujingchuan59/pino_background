<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"/Users/mac/Movies/Work/pinosearch.com/public/../application/admin/view/result/index.html";i:1528301625;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>搜索结果</title>
	<style type="text/css">
		*{
			padding:0;
			margin: 0;
			background-color: #92C9D9;
		}

		#head-link:visited{
			text-decoration: none;
		}
		#head-link:hover{
			text-decoration: none;
		}
		#head-link:active{
			text-decoration: none;
		}
		#head-link:link{
			text-decoration: none;
		}
		#head-link{
			color: white;
			font-size: 40px;
			border: 0;
		}
		#head-div{
			margin-left: 50px;
			margin-top: 40px;

		}

		#body-div{
			margin-left: 20%;
			margin-top: 15%;
		}

		#body-label{
			color: white;
			font-size: 40px;
			white-space: nowrap;
		}

		#body-more-button{
			margin-left: 30%;
			margin-top: 2%;
			border: none;
			color: white;
			background-color: #F66A49;
			width: 200px;
			height: 45px;
			border-radius: 8px;
			font-size: 15px;

		}

		#body-solve-problem-button{
			margin-left: 30%;
			margin-top: 2%;
			border: none;
			color: white;
			background-color: #F66A49;
			width: 200px;
			height: 45px;
			border-radius: 8px;
			font-size: 15px;

		}

	</style>
</head>

<!--head-->
<div id="head-div">
	<a id="head-link" href="<?php echo url('admin/index/index'); ?>">PINO一下,老师就来</a>
</div>

<!--body-->
<div id="body-div">
	<label id="body-label" href="#">恭喜您,已找到至少8位老师,老师们将尽快联系您.<br></label>
	<button id="body-more-button" onclick="javascript:history.go(-1);">再找更多...</button>
	<br>
	<button id="body-solve-problem-button" onclick="gotoSolveProblem()">看下大神们在解决什么...</button>
</div>

<!--footer-->

<!--script-->
<script type="text/javascript">


	function gotoSolveProblem() {

		window.location.href = "<?php echo url('admin/more/index'); ?>";

	}


</script>
</body>
</html>