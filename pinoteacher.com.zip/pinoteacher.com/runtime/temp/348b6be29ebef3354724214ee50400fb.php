<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"/Users/mac/Movies/Work/pinosearch.com/public/../application/admin/view/register/index.html";i:1528265002;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>注册Pino账号</title>

    <style type="text/css">

        *{
            padding: 0;
            margin: 0;
        }

        #head{
            font-size: 40px;
            color: #4A90E2;
            margin-left: 20%;
            margin-top: 30px;

        }
        #head:visited{
            text-decoration: none;
        }
        #head:hover{
            text-decoration: none;
        }
        #head:active{
            text-decoration: none;
        }
        #head:link{
            text-decoration: none;
        }

        #image{
            margin-top: 100px;
            float: right;
            margin-right: 10%;
        }

        .user-info{
            font-size: 20px;
            margin-left: 20%;
            color: #636c72;
        }
        .user-text{
            width: 300px;
        }

        #user-name{
            margin-top: 10%;
        }

        #name-text{
            margin-top: 10%;
            font-size: 15px;
            line-height: 33px;
        }

        #user-phone{
            margin-top: 3%;
        }

        #phone-text{
            margin-top: 3%;
            font-size: 15px;
            line-height: 33px;
        }

        #user-password{
            margin-top: 3%;
        }

        #password-text{
            margin-top: 3%;
            font-size: 15px;
            line-height: 33px;
        }

        #user-advantage{
            margin-top: 3%;

        }

        #advantage-text{
            margin-top: 3%;
            font-size: 15px;
            line-height: 33px;
        }
        #user-can-solve{

            margin-top: 3%;

        }

        #can-solve-text{
            margin-left: 20%;
            width: 26%;

        }
        #checkbox{
            margin-top: 20px;
            margin-left: 22%;
        }

        #statement{
            font-size: 10px;
        }

        .file{
            color: #4A90E2;
            text-decoration: none;
        }

        #submit{
            margin-left: 20%;
            margin-top: 30px;
            color: white;
            font-size: 17px;
            font-weight: bolder;
            border-width: 0;
            background-color: #4A90E2;
            width: 400px;
            height: 50px;
        }

        .footer{
            margin-top: 15%;
            margin-left:45%;

        }

        #footer-right{

            color: #4A90E2;

        }



    </style>
</head>
<body>
<!--head-->
<div>
<a id="head" href="<?php echo url('admin/index/index'); ?>">PINO | 注册账号</a>
    <img id="image" src="http://p5ml11w5w.bkt.clouddn.com/advertise.png"/>
</div>

<!--body-->
<div>
    <form action="<?php echo url('admin/register/addUser'); ?>" method="post" name="register-name">
        <label class="user-info" id="user-name">用户名</label>
        <input class="user-text" id="name-text" placeholder="请设置用户名" type="text" name="username" required/>
        <br>
        <label class="user-info" id="user-phone">手机号</label>
        <input class="user-text" id="phone-text" type="text" placeholder="用于登录和修改密码" name="phone" required/>
        <br>
        <label class="user-info" id="user-password">新密码</label>
        <input class="user-text" id="password-text" placeholder="请设置登录密码" type="password" name="password"/>
        <br>
        <label class="user-info" id="user-advantage">擅长于</label>
        <select name="category" class="category" required>
            <?php if(is_array($categories) || $categories instanceof \think\Collection || $categories instanceof \think\Paginator): $i = 0; $__LIST__ = $categories;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <option value="<?php echo $key; ?>"><?php echo $vo; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <br>
        <label class="user-info" id="user-can-solve">可解答</label>
        <br>
        <textarea class="user-text" id="can-solve-text" placeholder="请详细描述您所擅长领域的关键词,如托福阅读,PHP加载。同时,描述可以解决的问题,如托福某某文章或C++重载技术等." name="can-solve" rows="5" cols="20" required></textarea>
        <br>
        <input id="checkbox" type="checkbox" required/>
        <label id="statement">阅读并接受<a class="file" target="_blank" href="<?php echo url('admin/contract/index'); ?>">《匹诺曹用户协议》</a>及<a class="file" target="_blank" href="<?php echo url('admin/contract/index'); ?>">《匹诺曹隐私权保护声明》</a></label>
        <br>
        <button id="submit" onclick="">注册</button>

    </form>
</div>

<div>


</div>


<!--footer-->
</div>

<!--footer-->
<div class="footer">
    <label id="footer-right">2018©Pino</label>
</div>

<!--script-->
<script type="text/javascript">

    function createCode(len)
    {
        var seed = new Array(
                'abcdefghijklmnopqrstuvwxyz',
                'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                '0123456789'
        );               //创建需要的数据数组
        var idx,i;
        var result = '';   //返回的结果变量
        for (i=0; i<len; i++) //根据指定的长度
        {
            idx = Math.floor(Math.random()*3); //获得随机数据的整数部分-获取一个随机整数
            result += seed[idx].substr(Math.floor(Math.random()*(seed[idx].length)), 1);//根据随机数获取数据中一个值
        }



        return result; //返回随机结果
    }

    function test() {
        var inputRandom=document.getElementById("inputRandom").value;
        var autoRandom=document.getElementById("autoRandom").innerHTML;
        if(inputRandom==autoRandom) {
            alert("通过验证");
        } else {
            alert("没有通过验证");
        }

    }


    var countdown=60;
    function settime(obj) {

        if (countdown == 0) {
            obj.removeAttribute("disabled");
            obj.value="免费获取验证码";
            countdown = 60;
            return;
        } else {
            obj.setAttribute("disabled", true);
            obj.value="重新发送(" + countdown + ")";
            countdown--;
        }
        setTimeout(function() {
                    settime(obj) }
                ,1000)
    }

</script>
</body>
</html>