<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"/Users/mac/Movies/Work/pinosearch.com/public/../application/admin/view/login/index.html";i:1528168246;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pino登录</title>
    <style type="text/css">
        *{
            padding: 0;
            margin: 0;
        }

        #head{
            font-size: 40px;
            color: #4A90E2;
            margin-left: 20%;
            margin-top: 30px;

        }
        #head:visited{
            text-decoration: none;
        }
        #head:hover{
            text-decoration: none;
        }
        #head:active{
            text-decoration: none;
        }
        #head:link{
            text-decoration: none;
        }

        #image{
            margin-top: 100px;
            float: right;
            margin-right: 10%;
        }


        .user-info{
            font-size: 20px;
            margin-top: 20%;
            margin-left: 20%;
            color: #636c72;
        }
        .user-text{
            margin-top: 20%;
            width: 300px;
        }

        #user-phone{
            margin-top: 10%;
        }

        #phone-text{
            margin-top: 10%;
            font-size: 15px;
            line-height: 33px;
        }

        #user-password{
            margin-top: 3%;
            margin-left: 21.4%;
        }

        #password-text{
            margin-top: 3%;
            font-size: 15px;
            line-height: 33px;
        }

        #submit{
            margin-left: 20%;
            margin-top: 30px;
            color: white;
            font-size: 17px;
            font-weight: bolder;
            border-width: 0;
            background-color: #4A90E2;
            width: 400px;
            height: 50px;
        }

        .footer{
            margin-top: 20%;
            margin-left:45%;

        }

        #footer-right{
            color: #4A90E2;
        }
    </style>
</head>
<body>
<!--head-->
<div>
    <a id="head" href="<?php echo url('admin/index/index'); ?>">PINO | 用户登录</a>
    <img id="image" src="http://p5ml11w5w.bkt.clouddn.com/advertise.png"/>
</div>

<!--body-->
<div>
    <form action="<?php echo url('admin/login/login'); ?>" method="post">

        <label class="user-info" id="user-phone">手机号</label>
        <input class="user-text" id="phone-text" type="text" placeholder="手机/邮箱/用户名" name="phone" required/>
        <br>
        <label class="user-info" id="user-password">密码</label>
        <input class="user-text" id="password-text" placeholder="密码" type="password" name="password" required/>
        <br>
        <button id="submit" onclick="">登录</button>

    </form>
</div>

<!--footer-->
<div class="footer">
    <label id="footer-right">2018©Pino</label>
</div>

<!--script-->
<script type="text/javascript">


</script>
</body>
</html>