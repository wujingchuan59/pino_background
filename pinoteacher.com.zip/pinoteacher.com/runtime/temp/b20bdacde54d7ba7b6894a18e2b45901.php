<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"/Users/mac/Movies/Work/pinoteacher.com/public/../application/admin/view/more/index.html";i:1545443318;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <!--[if lt IE 9]>
    <script type="text/javascript" src="/static/hadmin/lib/html5shiv.js"></script>
    <script type="text/javascript" src="/static/hadmin/lib/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="/static/hadmin/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/hadmin/static/h-ui.admin/css/H-ui.admin.css" />
    <link rel="stylesheet" type="text/css" href="/static/hadmin/lib/Hui-iconfont/1.0.8/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="/static/hadmin/static/h-ui.admin/skin/default/skin.css" id="skin" />
    <link rel="stylesheet" type="text/css" href="/static/hadmin/static/h-ui.admin/css/style.css" />
    <!--[if IE 6]>
    <script type="text/javascript" src="__OSTATIC__/hadmin/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
    <script>DD_belatedPNG.fix('*');</script>
    <![endif]-->
    <title>PINO搜索结果</title>
    <style type="text/css">
        .header-section .header-top{
            height: 10%;
            background: none;
            padding-top: 2px;
            padding-bottom: 2px;

        }
        .header-section .header-top .container{

            margin-left: 1px;
            margin-top: 1px;

        }
        .header-section .header-top .head-content{

            margin-left: 1px;
            margin-top: 5px;
            height: 35px;
        }
        .head-logo{

            color: #00BCFF;
            font-weight: bolder;
            height: 30px;
            float: left;
            display: inline-block;
            padding-top: 3px;
            font-size: 18px;

        }
        .head-logo:link{
            color: #00BCFF;
        }
        .head-logo:visited{
            color: #00BCFF;
        }
        .head-logo:active{
            color: #00BCFF;
        }
        .head-logo:hover{
            color: #00BCFF;
        }
        .head-content .search-text{

            height: 30px;
            width: 45%;
            float: left;
            font-size: 13px;
            margin-left: 4px;
            margin-bottom: 0;
            padding: 0;

        }
        .head-content .more-search-button{

            width: 10%;
            height: 30px;
            color: #FFFFFF;
            background-color: #00BCFF;
            border: none;
            border-radius: 5px;
            margin-left: 5px;
        }

        .header-divider{

            width: 100%;
            height: 30px;
            background-color: #F8F8F8;

        }

        .header-divider .search-count{
            color: grey;
            margin-left: 17px;
            font-size: x-small;
            top: 2px;
        }

        body{
            margin-left: 0;
            margin-top: 0;
        }

        .problem-solver-name-label{

            font-size: small;
            color: darkgrey;

        }

        .problem-solver-name{
            font-size: small;
        }

        .problem-solver-phone-label{
            font-size: small;
            color: darkgray;
        }

        .problem-solver-phone{
            font-size: small;
            color: #000000;
        }

        .alipay-button{
            width: 20%;
            height: 20px;
            border-radius: 5px;
            font-size: 10px;
        }

        .consult-button{

            width: 10%;
            height: 20px;
            border-radius: 5px;
            font-size: 10px;
            background-color: white;
        }

        .remark-button{

            width: 10%;
            height: 20px;
            border-radius: 5px;
            margin-left: 2px;
            font-size: 10px;
            background-color: white;
        }

        .banner{

            background: none;

        }

        .banner .content-body{

            width: 60%;
            margin-left: 15px;
            float: left;

        }
        .banner .vertical-divider{

            width: 1px;
            height: 400px;
            color: #E1E1E1;
            background-color: #808080;
            float: left;
            margin-right: 20px;

        }

        .banner .content-body .problem-solved-content{

            text-decoration: underline;
            text-decoration-color: #071AC8;
            color: #071AC8;

        }

        .pino .pagination li{
            display:inline;
            padding-left:10px;
        }
        .copy{
            background-color: #00BCFF;
            border: none;
            position: fixed;
            bottom: 0;
            width: 101%;
            height: 10%;
            text-align: center;
        }
        .copy .copyright{
            color: #FFFFFF;
        }

        .copy .icp{
            color: #FFFFFF;
        }

        @media (max-width:1024px){
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }
            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }
            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }
            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #00BCFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:991px){
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }

            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:800px){
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }

            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:768px) {
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }

            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:736px){
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }

            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }
            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:667px){
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }

            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:640px) {
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }
            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:600px) {
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }
            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width:568px){
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }
            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }
            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

        }
        @media (max-width:480px){
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }

            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }
        }
        @media (max-width: 414px) {
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }
            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }
            .alipay-button{
                width: 20%;
                height: 20px;
                border-radius: 5px;
                font-size: 10px;
            }

            .consult-button{

                width: 20%;
                height: 20px;
                border-radius: 5px;
                font-size: 10px;

            }

            .remark-button{

                width: 20%;
                height: 20px;
                border-radius: 5px;
                margin-left: 2px;
                font-size: 10px;

            }

            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }

        }
        @media (max-width:384px) {
            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }

            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .alipay-button{
                width: 20%;
                height: 20px;
                border-radius: 5px;
                font-size: 10px;
            }

            .consult-button{

                width: 20%;
                height: 20px;
                border-radius: 5px;
                font-size: 10px;

            }

            .remark-button{

                width: 20%;
                height: 20px;
                border-radius: 5px;
                margin-left: 2px;
                font-size: 10px;

            }
            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }

            .copy{

                height: 8%;
                font-size: 10px;
                margin-top: 0;

            }

        }
        @media (max-width: 320px) {

            .header-section .header-top{
                height: 10%;
                background: none;
                padding-top: 2px;
                padding-bottom: 2px;

            }
            .header-section .header-top .container{

                margin-left: 1px;
                margin-top: 1px;

            }
            .header-section .header-top .head-content{

                margin-left: 1px;
                margin-top: 5px;
                height: 35px;
            }
            .head-logo{

                color: #00BCFF;
                font-weight: bolder;
                height: 25px;
                float: left;
                display: inline-block;
                padding-top: 3px;
                font-size: 14px;

            }
            .head-logo:link{
                color: #00BCFF;
            }
            .head-logo:visited{
                color: #00BCFF;
            }
            .head-logo:active{
                color: #00BCFF;
            }
            .head-logo:hover{
                color: #00BCFF;
            }

            .problem-solver-name-label{

                font-size: small;
                color: darkgrey;

            }

            .problem-solver-name{
                font-size: small;
            }

            .problem-solver-phone-label{
                font-size: small;
                color: darkgray;
            }

            .problem-solver-phone{
                font-size: small;
                color: #000000;
            }

            .alipay-button{
                width: 20%;
                height: 20px;
                border-radius: 5px;
                font-size: 10px;
            }
            .consult-button{

                width: 25%;
                height: 20px;
                border-radius: 5px;
                font-size: 10px;
            }

            .remark-button{

                width: 25%;
                height: 20px;
                border-radius: 5px;
                margin-left: 2px;
                font-size: 10px;
            }
            .head-content .search-text{

                height: 25px;
                width: 50%;
                float: left;
                font-size: 13px;
                margin-left: 4px;
                margin-bottom: 0;
                padding: 0;

            }
            .head-content .more-search-button{

                width: 60px;
                height: 25px;
                color: #FFFFFF;
                background-color: #00BCFF;
                border: none;
                font-size: 10px;
                border-radius: 5px;
                margin-left: 5px;

            }

            .banner .content-body{

                width: 100%;
                margin-left: 15px;
                float: left;

            }

            .banner .content-body .divider{

                width: 100%;
                height: 1px;

            }

            .banner .vertical-divider{

                display: none;

            }

            .banner .searched{
                display: none;
            }

            .copy{

                height: 8%;
                font-size: 10px;
                margin-top: 0;

            }

        }

    </style>
</head>
<body onload="bodyOnLoad()">
<!--header-->
<ul class="side_nav">
</ul>
<div class="header-section" id="home">
    <div class="header-top">
        <div class="container">
            <div class="head-content">
                <form class="head-form" id="head-form" method="post" action="<?php echo url('admin/more/search'); ?>">
                    <a class="head-logo" href="<?php echo url('admin/index/index'); ?>">PINO搜索</a>
                    <input class="search-text" onfocus="searchOnFocus(this)" value="<?php echo $search_content; ?>" type="text" name="searchInfo" placeholder="您需要找什么样人或解决什么难题?" required/>
                    <button class="more-search-button" type="submit"> P I N O </button>
                </form>
            </div>
        </div>
        <div class="header-divider">
            <label class="search-count">PINO为您找到相关结果约<?php echo $search_count; ?>个</label>
        </div>
        <br>
        <!--logo-->
    </div>
</div>
<!--banner-->
<div class="banner">
    <div class="content-body" id="content-div">
        <?php if(is_array($searchResult) || $searchResult instanceof \think\Collection || $searchResult instanceof \think\Paginator): $k = 0; $__LIST__ = $searchResult;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?>
        <div class="question_content-div">
            <label class="problem-solved-content" id="<?php echo $k; ?>"><?php echo $vo['can_solve']; ?></label>
            <br>
            <label class="problem-solver-name-label">姓名(称呼):&nbsp&nbsp</label>
            <label class="problem-solver-name"><?php echo $vo['username']; ?></label>
            <br>
            <label class="problem-solver-phone-label">联系方式(手机):</label>
            <label class="problem-solver-phone"><?php echo $vo['phone']; ?></label>
            <br>
            <label class="problem-solver-phone-label">QQ/微信:</label>
            <label class="problem-solver-phone"><?php echo $vo['wechat']; ?></label>
            <br>
            <label class="problem-solver-phone-label">用户评分:</label>
            <label class="problem-solver-phone">5.0</label>
            <br>
            <label class="problem-solver-phone-label">最新用户评价:</label>
            <label class="problem-solver-phone"><?php echo $vo['lastestRemark']; ?></label>
            <br>
            <button class="consult-button" id="consult_<?php echo $k; ?>" onclick="consultClick(this)">咨询</button>
            <button class="remark-button" id="remark_<?php echo $k; ?>" onclick="remarkClick(this)">评价</button>
            <br>
            <br>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        <br>
    </div>
    <hr class="vertical-divider">
    <div class="searched">
        <?php if(is_array($searchedResult) || $searchedResult instanceof \think\Collection || $searchedResult instanceof \think\Paginator): $i = 0; $__LIST__ = $searchedResult;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <div class="question_content-div">
            <label class="problem-solved-content"><?php echo $vo['content']; ?></label>
            <br>
            <label class="problem-solver-name-label">姓名(称呼):</label>
            <label class="problem-solver-name"><?php echo $vo['username']; ?></label>
            <label class="problem-solver-phone-label">联系方式(手机):&nbsp&nbsp&nbsp</label>
            <label class="problem-solver-phone"><?php echo $vo['phone']; ?></label>
            <label class="problem-solver-phone-label">QQ/微信:&nbsp&nbsp&nbsp</label>
            <label class="problem-solver-phone"><?php echo $vo['wechat']; ?></label>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
</div>

<!--//contact-->

<div class="copy">
    <p class="copyright">
        Copyright © 2018. All rights reserved.
    </p>
    <p class="icp">
        京ICP证17059422号
    </p>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="/static/hadmin/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/hadmin/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="/static/hadmin/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="/static/hadmin/static/h-ui.admin/js/H-ui.admin.js"></script> <!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="/static/hadmin/lib/datatables/1.10.0/jquery.dataTables.min.js"></script>
<script type="text/javascript">

    //页面加载完毕后的状态
    function bodyOnLoad() {
        //让指定字体改变颜色
        //1.通过ajax获得搜索内容
        $.ajax({
            type: 'post',
            url: '/admin/ajax/handleResult',
            dataType:'json',
            data: {

            },
            beforeSend:function (msg) {
            },
            success: function (response) {
                //content
                var content = response["content"];
                if(content.length > 0){
                    var searchCount = response["count"];
                    for(var i = 1 ; i <= searchCount ; i++){
                        //获得label内容
                        var label = document.getElementById(i);
                        //判断哪个字符是属于搜索关键字字符
                        var tempLabel = document.createElement("tempLabel");
                        //如果当前值是在content当中
                        for(var j = 0 ; j < label.innerHTML.length ; j++){
                            if(content.indexOf(label.innerHTML.charAt(j)) != -1){
                                var newElement = document.createElement("highlight_label");
                                newElement.innerHTML = label.innerHTML.charAt(j);
                                newElement.style.color = "red";
                                tempLabel.appendChild(newElement);
                            }else{
                                //如果当前值不是在label当中
                                var newElement2 = document.createElement("unhighlight_label");
                                newElement2.innerHTML = label.innerHTML.charAt(j);
                                tempLabel.appendChild(newElement2);
                            }
                        }
                        //赋值
                        label.innerHTML = tempLabel.innerHTML;
                    }

                }
            }
        });

    }

    //搜索框点击时候的行为
    function searchOnFocus(obj) {

        //清空搜索数据
        obj.value = "";

    }

    //支付宝支付
    function alipayClick(obj) {

        alert('paying');


    }

    //咨询按钮点击事件
    function consultClick(obj) {
        //获取当前id
        var rawId = obj.id;
        //去掉id中的多于字符
        var id = rawId.replace("consult_","");
        //让用户键入咨询问题
        var question = prompt("请输入您的咨询问题");
        //输入问题不能为空且需要字符数大于零
        if(question != null && question.length != 0){
            //让用户键入联系方式
            var contact = prompt("请输入您的联系方式");
            //输入联系方式不能为空且需要字符数大于零
            if(contact != null && contact.length != 0){
                //开始ajax传值
                //ajax传值
                $.ajax({
                    type: 'post',
                    url: '/admin/ajax/handleUserConsult',
                    dataType:'json',
                    data: {
                        id : id,
                        contact : contact,
                        question : question
                    },
                    beforeSend:function (msg) {
                    },
                    success: function (response) {
                        //获得返回状态码
                        var status = response["errorno"];
                        if(status == 0){
                            alert("发送成功，建议您主动添加联系方式");
                        }
                    }
                });
            }
        }
    }
    //点击评价事件
    function remarkClick(obj) {
        //获取当前id
        var rawId = obj.id;
        //去掉id中的多于字符
        var id = rawId.replace("remark_","");
        //让用户键入咨询问题
        var remark = prompt("请输入您的评价");
        //输入的评价不能为空且需要字符数大于零
        if(remark != null && remark.length != 0){
            $.ajax({
                type: 'post',
                url: '/admin/ajax/handleUserRemark',
                dataType:'json',
                data: {
                    id : id,
                    remark : remark
                },
                beforeSend:function (msg) {
                },
                success: function (response) {
                    if(response["errorno"] == 0){

                        alert("评价成功");
                    }
                }
            });
        }
    }

    /*管理员-角色-添加*/
    function admin_role_add(title,url,w,h){
        layer_show(title,url,w,h);
    }
    /*管理员-角色-编辑*/
    function admin_role_edit(title,url,id,w,h){
        layer_show(title,url,w,h);
    }
    /*管理员-角色-删除*/
    function admin_role_del(obj,id){
        layer.confirm('角色删除须谨慎，确认要删除吗？',function(index){
            $.ajax({
                type: 'POST',
                url: '',
                dataType: 'json',
                success: function(data){
                    $(obj).parents("tr").remove();
                    layer.msg('已删除!',{icon:1,time:1000});
                },
                error:function(data) {
                    console.log(data.msg);
                }
            });
        });
    }
</script>
</body>
</html>