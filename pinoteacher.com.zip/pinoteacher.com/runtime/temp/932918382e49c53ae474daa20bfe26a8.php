<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"/Users/mac/Movies/Work/pinoteacher.com/public/../application/admin/view/login/index.html";i:1531754835;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <title> Pino 用户登录 </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Tuition Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="/static/hadmin/static/login/css/bootstrap.css" rel='stylesheet' type='text/css' />
    <!-- Custom Theme files -->
    <link href="/static/hadmin/static/login/css/style.css" rel='stylesheet' type='text/css' />
    <link href="/static/hadmin/static/login/css/swipebox.css" rel='stylesheet' type='text/css' />
    <script src="/static/hadmin/static/login/js/jquery-1.11.1.min.js"></script>
    <script src="/static/hadmin/static/login/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/login/js/move-top.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/login/js/easing.js"></script>
    <link href='https://fonts.googleapis.com/ css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
    <!--/script-->
    <script src="/static/hadmin/static/login/js/modernizr.custom.97074.js"></script>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},900);
            });
        });
    </script>
    <!--script-->
    <script src="/static/hadmin/static/login/js/jquery.swipebox.min.js"></script>
    <script type="text/javascript">
        jQuery(function($) {
            $(".swipebox").swipebox();
        });

    </script>

    <style type="text/css">

        .banner-top {

            margin-top: 0;
            width: 50%;
            position: absolute;
            right: 50%;
            margin-right: -25%;

        }

        .banner{

            background: none;
            height: 75%;

        }

        .banner .banner-top .header{
            color: #00BCFF;
        }

        .content .user-text{
            width: 100%;
        }

        #submit{

            width: 100%;
            color: #FFFFFF;
            background-color: #00BCFF;
            line-height: 40px;
            border: none;
            font-size: 20px;
            border-radius: 5px;

        }

        @media (max-width: 1024px) {
            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 100px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 60%;
                position: absolute;
                right: 50%;
                margin-right: -30%;

            }

        }

        @media (max-width: 414px) {
            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 20px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }

        }

        @media (max-width:384px) {
            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 20px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }

        }

        @media (max-width: 320px) {

            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 20px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }


        }



    </style>
</head>
<body onload="bodyOnLoad()">
<!--header-->
<!--banner-->
<div class="banner">
    <div class="banner-top">
        <h3 class="header">Pino | 用户登录</h3>
        <br>
        <br>
        <br>
        <br>
        <div class="content">
            <div>
                <form action="<?php echo url('admin/login/login'); ?>" method="post">
                    <input class="user-text" id="phone-text" type="text" placeholder="手机/邮箱/用户名" name="phone" required/>
                    <br>
                    <input class="user-text" id="password-text" placeholder="密码" type="password" name="password" required/>
                    <br>
                    <button id="submit" onclick="">登录</button>
                </form>
            </div>
        </div>
        <div>
        </div>
    </div>

    <!--//contact-->

    <!--start-smooth-scrolling-->
    <script type="text/javascript">

        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
            });
        });
    </script>
    <!--start-smoth-scrolling-->
    <script type="text/javascript">

        $(document).ready(function() {
            /*
             var defaults = {
             containerID: 'toTop', // fading element id
             containerHoverID: 'toTopHover', // fading element hover id
             scrollSpeed: 1200,
             easingType: 'linear'
             };
             */

            $().UItoTop({ easingType: 'easeOutQuart' });

        });
    </script>
    <a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

</body>
</html>