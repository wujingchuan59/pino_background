<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"/Users/mac/Movies/Work/pinoteacher.com/public/../application/admin/view/register/index.html";i:1536569543;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <title> Pino 注 册 </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Tuition Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="/static/hadmin/static/register/css/bootstrap.css" rel='stylesheet' type='text/css' />
    <!-- Custom Theme files -->
    <link href="/static/hadmin/static/register/css/style.css" rel='stylesheet' type='text/css' />
    <link href="/static/hadmin/static/register/css/swipebox.css" rel='stylesheet' type='text/css' />
    <script src="/static/hadmin/static/register/js/jquery-1.11.1.min.js"></script>
    <script src="/static/hadmin/static/register/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/register/js/move-top.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/register/js/easing.js"></script>
    <link href='https://fonts.googleapis.com/ css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
    <!--/script-->
    <script src="/static/hadmin/static/register/js/modernizr.custom.97074.js"></script>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},900);
            });
        });
    </script>
    <!--script-->
    <script src="/static/hadmin/static/register/js/jquery.swipebox.min.js"></script>
    <script type="text/javascript">
        jQuery(function($) {
            $(".swipebox").swipebox();
        });

    </script>

    <style type="text/css">

        .banner-top {

            margin-top: 0;
            width: 50%;
            position: absolute;
            right: 50%;
            margin-right: -25%;

        }

        .banner{

            background: none;
            height: 75%;

        }

        .banner .banner-top .header{
            color: #00BCFF;
        }

        .content .user-text{
            width: 100%;
        }

        .content .category{

            width: 100%;
            text-align: center;
            background-color: #00BCFF;
            color: #FFFFFF;
            border: none;

        }

        #submit{

            width: 100%;
            color: #FFFFFF;
            background-color: #00BCFF;
            line-height: 40px;
            border: none;
            font-size: 20px;
            border-radius: 5px;

        }

        @media (max-width: 1024px) {


            .banner .banner-top .header{
                color: #00BCFF;
                font-size: 40px;
                margin-top: 80px;
            }


        }

        @media (max-width: 414px) {

            .banner-top {

                margin-top: 10px;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }

            .banner .banner-top .header{
                color: #00BCFF;
                font-size: 20px;
            }
            .user-text{

                height: 15px;
                margin-top: 1px;

            }
        }

        @media (max-width:384px) {
            .banner-top {

                margin-top: 10px;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }

            .banner .banner-top .header{
                color: #00BCFF;
                font-size: 20px;
            }
            .user-text{

                height: 15px;
                margin-top: 1px;

            }
        }

        @media (max-width: 320px) {

            .banner-top {

                margin-top: 10px;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }

            .banner .banner-top .header{
                color: #00BCFF;
                font-size: 20px;
            }
            .user-text{

                height: 15px;
                margin-top: 1px;

            }


        }



    </style>
</head>
<body onload="bodyOnLoad()">
<!--header-->
<!--banner-->
<div class="banner">
    <div class="banner-top">
        <h3 class="header">Pino | 用户注册</h3>
        <div class="content">
            <form action="<?php echo url('admin/register/addUser'); ?>" method="post" name="register-name">
                <input class="user-text" id="name-text" placeholder="请设置用户名" type="text" name="username" required/>
                <br>
                <input class="user-text" id="phone-text" type="text" placeholder="您的电话、用于登录和修改密码" name="phone"/>
                <br>
                <input class="user-text" id="wechat-text" type="text" placeholder="您的微信号(电话微信二选一)" name="wechat"/>
                <br>
                <input class="user-text" id="password-text" placeholder="请设置登录密码" type="password" name="password"/>
                <br>
                <select name="category" class="category" required>
                    <?php if(is_array($categories) || $categories instanceof \think\Collection || $categories instanceof \think\Paginator): $i = 0; $__LIST__ = $categories;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option value="<?php echo $key; ?>"><?php echo $vo; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
                <br>
                <br>
                <textarea class="user-text" id="can-solve-text" placeholder="请详细描述您所擅长领域的关键词,如托福阅读,PHP加载。同时,描述可以解决的问题,如托福某某文章或C++重载技术等." name="can-solve" rows="5" cols="20" required></textarea>
                <br>
                <input id="checkbox" type="checkbox" required/>
                <label id="statement">阅读并接受<a class="file" target="_blank" href="<?php echo url('admin/contract/index'); ?>">《匹诺曹用户协议》</a>及<a class="file" target="_blank" href="<?php echo url('admin/contract/index'); ?>">《匹诺曹隐私权保护声明》</a></label>
                <br>
                <br>
                <button id="submit" onclick="">注册</button>
            </form>
        </div>
        <div>
    </div>
</div>

<!--//contact-->

<!--start-smooth-scrolling-->
<script type="text/javascript">

    jQuery(document).ready(function($) {
        $(".scroll").click(function(event){
            event.preventDefault();
            $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
        });
    });
</script>
<!--start-smoth-scrolling-->
<script type="text/javascript">

    $(document).ready(function() {
        /*
         var defaults = {
         containerID: 'toTop', // fading element id
         containerHoverID: 'toTopHover', // fading element hover id
         scrollSpeed: 1200,
         easingType: 'linear'
         };
         */

        $().UItoTop({ easingType: 'easeOutQuart' });

    });
</script>
</div>
</body>
</html>