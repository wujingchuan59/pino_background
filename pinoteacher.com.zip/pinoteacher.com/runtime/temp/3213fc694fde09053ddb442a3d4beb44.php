<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:92:"/Users/mac/Movies/Work/pinoteacher.com/public/../application/admin/view/usersetup/index.html";i:1531788412;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
    <title> Pino 用户设置 </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Tuition Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="/static/hadmin/static/usersetup/css/bootstrap.css" rel='stylesheet' type='text/css' />
    <!-- Custom Theme files -->
    <link href="/static/hadmin/static/usersetup/css/style.css" rel='stylesheet' type='text/css' />
    <link href="/static/hadmin/static/usersetup/css/swipebox.css" rel='stylesheet' type='text/css' />
    <script src="/static/hadmin/static/usersetup/js/jquery-1.11.1.min.js"></script>
    <script src="/static/hadmin/static/usersetup/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/usersetup/js/move-top.js"></script>
    <script type="text/javascript" src="/static/hadmin/static/usersetup/js/easing.js"></script>
    <link href='https://fonts.googleapis.com/ css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
    <!--/script-->
    <script src="/static/hadmin/static/usersetup/js/modernizr.custom.97074.js"></script>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},900);
            });
        });
    </script>
    <!--script-->
    <script src="/static/hadmin/static/usersetup/js/jquery.swipebox.min.js"></script>
    <script type="text/javascript">
        jQuery(function($) {
            $(".swipebox").swipebox();
        });

    </script>

    <style type="text/css">

        .banner-top {

            margin-top: 0;
            width: 50%;
            position: absolute;
            right: 50%;
            margin-right: -25%;

        }

        .banner{

            background: none;
            height: 75%;

        }

        .banner .banner-top .header{
            color: #00BCFF;
        }

        .content .user-text{
            width: 100%;
        }

        .category{

            width: 100%;
            text-align: center;
            background-color: #00BCFF;
            color: #FFFFFF;
            border: none;

        }

        #submit{

            width: 100%;
            color: #FFFFFF;
            background-color: #00BCFF;
            line-height: 40px;
            border: none;
            font-size: 20px;
            border-radius: 5px;

        }

        @media (max-width: 1024px) {
            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 100px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 60%;
                position: absolute;
                right: 50%;
                margin-right: -30%;

            }

        }

        @media (max-width: 414px) {
            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 20px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }

        }

        @media (max-width:384px) {
            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 20px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }

        }

        @media (max-width: 320px) {

            .banner .banner-top .header{
                color: #00BCFF;
                margin-top: 20px;
                font-size: 30px;
            }

            .banner-top {

                margin-top: 0;
                width: 90%;
                position: absolute;
                right: 50%;
                margin-right: -45%;

            }


        }



    </style>
</head>
<body onload="bodyOnLoad()">
<!--header-->
<!--banner-->
<div class="banner">
    <div class="banner-top">
        <h3 class="header"> Pino | 用户设置 </h3>
        <br>
        <div class="content">
            <div class="user-info" id="body-div">
                <form action="<?php echo url('admin/usersetup/updateUserInfo'); ?>" method="post" name="register-name">
                    <input class="user-text" id="name-text" placeholder="更新用户名" type="text" name="username" required/>
                    <br>
                    <input class="user-text" id="qq-text" placeholder="设置qq账号" type="text" name="qq" required/>
                    <br>
                    <input class="user-text" id="password-text" placeholder="更新登录密码" type="password" name="password" required/>
                    <br>
                    <select name="category" class="category" required>
                        <?php if(is_array($categories) || $categories instanceof \think\Collection || $categories instanceof \think\Paginator): $i = 0; $__LIST__ = $categories;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $key; ?>"><?php echo $vo; ?></option>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                    <br>
                    <br>
                    <textarea id="can-solve-text-area" class="user-info" name="can_solve" rows="3" cols="35" placeholder="请详细描述您所擅长领域的关键词,如托福阅读,PHP加载。同时,描述可以解决的问题,如托福某某文章或C++重载技术等." required></textarea>
                    <br>
                    <button id="submit" onclick="">更新信息</button>
                </form>
            </div>
        </div>
        <div>
        </div>
    </div>

    <!--//contact-->

    <!--start-smooth-scrolling-->
    <script type="text/javascript">

        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
            });
        });
    </script>
    <!--start-smoth-scrolling-->
    <script type="text/javascript">

        $(document).ready(function() {
            /*
             var defaults = {
             containerID: 'toTop', // fading element id
             containerHoverID: 'toTopHover', // fading element hover id
             scrollSpeed: 1200,
             easingType: 'linear'
             };
             */

            $().UItoTop({ easingType: 'easeOutQuart' });

        });
    </script>

</body>
</html>