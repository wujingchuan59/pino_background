# -*- coding: utf-8 -*-
import scrapy


class ZhihuSpider(scrapy.Spider):
    name = 'zhihu'
    allowed_domains = ['https://zhihu.com']
    start_urls = ['http://https://zhihu.com/']

    def parse(self, response):
        pass


