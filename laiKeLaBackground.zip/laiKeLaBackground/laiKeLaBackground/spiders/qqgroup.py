# -*- coding: utf-8 -*-
import scrapy
import time
import requests
import json
import random
from selenium.webdriver.common.action_chains import  ActionChains
import os
from selenium import webdriver

class QqgroupSpider(scrapy.Spider):
    # 设置url,用于从来客啦数据库获取需要检索的关键词
    url = 'https://www.pinoteacher.com/admin/Respond/getAllQQGroupInfo'
    # 开始链接来客啦后台获得数据
    result = requests.get(url)
    # json分解数据，获得全部的需要检索的数据以及账号等信息
    if result:
        resultArray = json.loads(result.content)
    else:
        exit()

    # 爬虫基本信息
    name = 'qqgroup'
    allowed_domains = ['https://qun.qq.com/member.']
    # 整理resultArray,使得从数据库获得数据成为这样的格式：[qq账号1,群号]....[qq账号1,群号][qq账号2,群号]....[qq账号2,群号]
    new_result_array = []
    different_qq_num = []
    # 首先统计不同的qq账号有多少个,保证qq号不重复，当前数据格式：['账号', '密码']
    for data in resultArray:
        tempData = [data['qq_num'], data['password']]
        # 如果当前数据不在different_qq_num里面，则添加该数据
        if tempData not in different_qq_num:
            different_qq_num.append([data['qq_num'], data['password']])
    # 然后根据不同账号账号，把全部账号信息整理好
    for qq_num in different_qq_num:
        for data in resultArray:
            if data['qq_num'] == qq_num[0] and data not in new_result_array:
                new_result_array.append(data)

    # 整理出来数据初始化start_urls
    if len(resultArray) > 0:
        url = 'https://qun.qq.com/member.html#gid=' + new_result_array[0]['qq_group_num']
        start_urls = [url]
    else:
        url = 'https://qun.qq.com/member.html#gid=209651835'
        start_urls = [url]

    # 分析数据
    def parse(self, response):
        # 分别处理不同的页面数据
        searched_group = []
        for temp_qq_num in self.different_qq_num:
            # 根据不同账号，密码，群号，登录
            qq_num = temp_qq_num[0]
            qq_password = temp_qq_num[1]
            qq_group_num = ''
            qq_group_name = ''
            # 查找该qq号的第一个群号
            for result in self.new_result_array:
                if result['qq_num'] == qq_num:
                    qq_group_num = result['qq_group_num']
                    qq_group_name = result['name']
                    break
            # 开始登录： 存储cookie, 并返回driver
            driver = self.login(qq_num, qq_password, qq_group_num)
            self.parse_group_first_login(driver, qq_group_name, qq_group_num, qq_num)
            # 将第一个群信息添加进入数组
            searched_group.append(qq_group_num)
            # 登录完成后，根据不同的qq号截取全部的qq群账号，逐个替换登录
            for data in self.new_result_array:
                if data['qq_num'] == qq_num:
                    qq_group_num = data['qq_group_num']
                    qq_group_name = data['name']
                    qq_num = data['qq_num']
                    # 保证当前qq群还没有被遍历，然后开始搜集数据
                    if qq_group_num not in searched_group:
                        # 添加当前qq群号到数组，保证下次不再遍历该群号
                        searched_group.append(qq_group_num)
                        # 开始获得当前群的数据
                        self.parse_other_group(driver, qq_group_name, qq_group_num, qq_num)
                        # 分析完当前群，暂停几秒
                        self.sleep_random(3, 5)
        pass

    # 登录qq
    def login(self, qq_num, password, group):
        # 设置chrome为静默模式
        option = webdriver.ChromeOptions()
        option.add_argument('--headless')
        option.add_argument('--no-sandbox')
        option.add_argument('--start-maximized')
        driver = webdriver.Chrome(options=option)
        # 设置driver大小
        driver.set_window_rect(0, 0, 1200, 1024)
        # 第一步先登录: 要保证当前qq_num的确有
        qq_group_num = group
        url = 'https://qun.qq.com/member.html#gid=' + qq_group_num
        driver.get(url)
        self.sleep_random(2, 3)
        driver.switch_to.frame("login_frame")  # 进入登录iframe
        change = driver.find_element_by_id("switcher_plogin")
        change.click()
        driver.find_element_by_id('u').clear()  # 选择用户名框
        driver.find_element_by_id('u').send_keys(qq_num)
        driver.find_element_by_id('p').clear()
        driver.find_element_by_id('p').send_keys(password)
        driver.find_element_by_class_name("login_button").click()
        # 点击排序，从新到旧
        self.click_sort_desc(driver)
        # 现在登录已经完成
        # 获取cookie
        self.sleep_random(7, 10)
        cookies = driver.get_cookies()
        # 移到排序位置
        # 存储cookies
        json_cookies = json.dumps(cookies)
        # 如果已经有该账号的cookie，则利用该cookie进行登录
        # 首先判断文件是否存在
        cookie_file_path = '/Users/mac/laiKeLaBackground/cookies/qq.json'
        # 存储数据
        with open(cookie_file_path, 'w') as f:
            f.write(json_cookies)
            f.close()
        time.sleep(5)
        return driver
    pass

    # 分析群信息
    def parse_group_first_login(self, driver, group_name, group_num, owner_num):
        # 分析整理信息
        member = driver.find_elements_by_class_name("mb")
        member_infos_array = member
        # 用for循环遍历全部的qq群成员信息
        for member_info in member_infos_array:
            # 获得当前的元素信息
            element = member_info.find_elements_by_tag_name("td")
            # 整理群信息
            info_collected = ''
            for info in element:
                info_collected = info_collected + '&' + info.text
            # 发送整理好的信息
            self.sendData(info_collected, group_name, group_num, owner_num)
        # 程序暂停暂定10-15秒钟
        self.sleep_random(10, 15)
    pass

    # 分析其他群信息
    def parse_other_group(self, driver, group_name, group, owner_num):
        # 如果已经有该账号的cookie，则利用该cookie进行登录
        # 首先判断文件是否存在
        cookie_file_path = '/Users/mac/laiKeLaBackground/cookies/qq.json'
        cookie_file = os.path.exists(cookie_file_path)
        # 如果文件存在，则读取文件
        if cookie_file:
            with open(cookie_file_path, 'r', encoding='utf-8') as file:
                list_cookies = json.loads(file.read())
                url = 'https://qun.qq.com/member.html#gid=' + group
                driver.get(url)
                for list1 in list_cookies:
                    driver.add_cookie(list1)
                driver.refresh()
                # 点击排序，从新到旧
                self.click_sort_desc(driver)
                # 分析整理信息
                member = driver.find_elements_by_class_name("mb")
                member_infos_array = member
                # 用for循环遍历全部的qq群成员信息
                for member_info in member_infos_array:
                    # 获得当前的元素信息
                    element = member_info.find_elements_by_tag_name("td")
                    # 整理群信息
                    info_collected = ''
                    for info in element:
                        info_collected = info_collected + '&' + info.text
                    # 发送整理好的信息
                    self.sendData(info_collected, group_name, group, owner_num)
                time.sleep(10)
    pass

    # 点击排序安牛逼
    def click_sort_desc(self, driver):
        # 找到要点击的元素
        driver.implicitly_wait(2)
        join_time = driver.find_element_by_css_selector('#groupTh > th:nth-child(8) > div > div > a')
        ActionChains(driver).move_to_element(join_time).click().perform()
        driver.implicitly_wait(1)
        desc = driver.find_element_by_css_selector('#groupTh > th.th-left.th-desc.selected > div > div > ul > li:nth-child(3) > i')
        ActionChains(driver).move_to_element(desc).click().perform()
    pass

    # 随机睡眠几秒
    def sleep_random(self, lower, upper):
        sleep = random.randint(lower, upper)
        time.sleep(sleep)
    pass

    # 发送消息
    def sendData(self, data, group_name, group_num, owner_num):
        # 对数据进行整理
        data = self.concate_result(data, group_name, group_num, owner_num)
        # 开始发送数据，保证当前数据长度大于零
        if len(data) > 0:
            # 开始准备发送数据的url
            url = "https://www.pinoteacher.com/admin/Respond/saveAllQQGroupMemberInfo"
            # 设置数据
            values = {
                'data': data
            }
            # 设置发送头
            headers = {'content-type': 'charset=utf8'}
            # 开始发送数据，用utf-8整理
            requests.post(url, data=json.dumps(values).encode('utf-8'), headers=headers)
    pass

    # 整理最终的字符串结果
    def concate_result(self, data, group_name, group_num, owner_num):
        if len(data) > 0:
            # 分裂字符数据
            str_array = data.split('&')
            # 定义最终数组格式
            final_array = []
            # 将分裂后的字符加入最终数据格式（要保证每一个数据长度大于零）
            for temp_str in str_array:
                # 字符串长度必须大于零，才
                if len(temp_str) > 0:
                    final_array.append(temp_str)
            # 将最终的群数据整理到最终数组中
            final_array.append(group_name)
            final_array.append(group_num)
            final_array.append(owner_num)
            # 去除多余的内容
            if len(final_array) == 11:
                final_array.pop(6)
            if len(final_array) == 12:
                final_array.pop(2)
                final_array.pop(7)
            # 返回数据
            return final_array
