// pay/pay.js
var util = require('../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    moneyAmount: 0,
    teacherInfo: [],
    orderName: '',
    orderPhone: '',
    invitationCode: 'null',
    payerDiscount: 0.0,
    moneyAmountLabel: '输入金额'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //设置导航条颜色
    wx.setNavigationBarColor({
        frontColor: '#ffffff',
        backgroundColor: '#3988FB',
      }),
      //设置导航条标题
      wx.setNavigationBarTitle({
        title: '微信支付',
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    //赋值
    var teacherInfo = wx.getStorageSync('teacherInfo_Pay')
    var time = util.formatTime(new Date());
    var date = util.formatDate(new Date());
    if (teacherInfo['wechat'] != '暂无') {
      this.setData({
        teacherInfo: teacherInfo,
        date: date,
        time: time,
        contact: teacherInfo['wechat']
      })
    } else {
      this.setData({
        teacherInfo: teacherInfo,
        date: date,
        time: time,
        contact: teacherInfo['phone']
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //验证用户输入完毕时候的行为
  bindInput: function(e) {
    this.setData({
      moneyAmount: e.detail.value
    })
  },
  orderPhone: function(e) {
    this.setData({
      orderPhone: e.detail.value
    })
  },
  orderName: function(e) {
    this.setData({
      orderName: e.detail.value
    })
  },
  invitationCode: function(e) {
    this.setData({
      invitationCode: e.detail.value
    })
  },
  //用户输入完金额之后提示用户金额
  moneyInputDone: function(e) {
    //获得邀请码
    var invitationCode = this.data.invitationCode
    console.log(invitationCode)
    if (invitationCode != 'null') {
      //设置需要付款的钱
      var currentMoney = this.data.moneyAmount
      var discountRate = (1- this.data.payerDiscount)
      var moneyToPayDiscounted = currentMoney * discountRate
      //提示用户即将优惠
      this.setData({
        moneyAmountLabel: '已获优惠',
        moneyAmount:moneyToPayDiscounted
      })
      //提示用户实际支付数额      
      wx.showToast({
        title: '实付:' + moneyToPayDiscounted,
      }) 
    }
  },
  checkInvitation: function(e) {
    //传递数值
    var that = this
    //开始连接服务器验证邀请码是否存在
    var invitationCode = e.detail.value
    //保证邀请码不能为空且字符串数目大于4，否则警告用户无效验证码，满足这个条件在和服务器进行校验
    if (invitationCode != null && invitationCode.length > 4) {
      //开始发送数据给后台验证邀请码是否有效
      wx.showLoading({
        title: '验证中',
        success: function() {
          that.sendData()
        }
      })
    } else {
      //如果验证码无效，则去除优惠
      this.setData({
        moneyAmountLabel: '请输入金额',
        payerDiscount: 0.0,
        invitationCode:'null'
      })
      wx.showToast({
        title: '无效邀请码',
        icon: 'none'
      })
    }
  },
  /**
   * 用于验证邀请码是否有效
   */
  sendData: function() {
    //保证用户输入值不为空
    var jsonData = JSON.stringify(this.data.remark)
    var that = this
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/verifyInvitationCode
      url: 'https://www.pinoteacher.com/admin/Respond/verifyInvitationCode',
      data: {
        invitation_code: this.data.invitationCode
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        //成功获得返回值，则隐藏loading
        wx.hideLoading({
          success: function() {
            //currently do nothing
          }
        })
        //成功隐藏加载时候提示信息
        //根据返回结构判断最终值
        if (res.data != 0) {
          //获得返回值
          var result = res.data
          //根据返回值给用户反馈
          var status = result['status']
          //如果验证码为零
          if (status == 0) {
            setTimeout(function() {
              wx.showToast({
                title: '邀请码无效',
                icon: 'none'
              })
            }, 100)
            //设置当前邀请码为空
            that.setData({
              invitationCode: 'null',
              payerDiscount:0.0,
              moneyAmountLabel:'请输入金额'
            })
            //返回主程序
            return
          } 
          if (status == 1) {
            setTimeout(function() {
              wx.showToast({
                title: '邀请码有效',
              })
            }, 100)
            //设置当前有效邀请码
            that.setData({
              invitationCode: that.data.invitationCode
            })
            //设置返回的优惠比例
            that.setData({
              payerDiscount: result['discount']
            })
          }
        }
      },
      fail: function() {
        console.log('fail')
      },
      complete: function() {}
    })

  },
  /**
   * 用于支付费用
   */
  payByWechat: function() {
    //传值，将this赋值给that
    var that = this
    //首先保证用户输入的金钱数额不为空
    if (this.data.orderName.length != 0 && this.data.orderPhone.length == 11) {
      if (this.data.moneyAmount != 0 && this.data.moneyAmount != null) {
        //获得服务商信息
        var teacherInfo = wx.getStorageSync('teacherInfo_Pay')
        //确认支付
        var contact = ''
        if (teacherInfo['phone'] != '暂无') {
          contact = teacherInfo['phone']
        } else if (teacherInfo['wechat'] != '暂无') {
          contact = teacherInfo['wechat']
        } else {
          contact = 'nil'
        }
        //开始支付
        if (contact != 'nil') {
          //确认支付
          wx.showModal({
            title: '确认支付',
            content: this.data.orderName + ' ' + this.data.orderPhone,
            success: function(res) {
              that.payByCertain(contact)
            }
          })
        } else {
          wx.showToast({
            title: '服务商信息错误',
            icon: 'none'
          })
        }
      } else {
        wx.showToast({
          title: '金额输入错误',
          icon: 'none'
        })
      }
    } else {
      wx.showToast({
        title: '电话或姓名不对',
        icon: 'none'
      })
    }
  },
  //确认开始支付
  payByCertain(contact) {
    //传值，将this赋值给that
    var that = this
    //开始支付
    wx.login({
      success: function(res) {
        //如果登录成功
        if (res.code) {
          wx.request({
            url: 'https://www.pinoteacher.com/admin/Respond/wechatPay',
            data: {
              code: res.code,
              server: contact,
              total_fee: that.data.moneyAmount
            },
            method: 'POST',
            success: function(res) {
              //发起支付
              wx.requestPayment({
                timeStamp: res.data['timeStamp'],
                nonceStr: res.data['nonceStr'],
                package: res.data['package'],
                signType: res.data['signType'],
                paySign: res.data['paySign'],
                success: function(data) {
                  //支付成功后将支付结果发送给服务器后台，来分配金额以及佣金
                  that.redistributeMoney(contact)
                  //存储订单
                  that.saveOrder(contact)
                  //存储付款数据和收款人
                  wx.setStorage({
                    key: 'money-amout',
                    data: that.data.moneyAmount,
                  })
                  wx.setStorage({
                    key: 'sever-contact',
                    data: contact,
                  })
                  wx.setStorage({
                    key: 'pay_date',
                    data: that.data.date,
                  })
                  wx.setStorage({
                    key: 'pay_time',
                    data: that.data.time,
                  })
                  //支付成功后导航到支付成功页面
                  //导航到支付成功页面
                  wx.navigateTo({
                    url: '../payDone/payDone',
                  })
                },
                fail: function(msg) {
                  console.log(msg)
                }
              })
            },
            fail: function(res) {
              console.log('fail to request')
            },
            complete: function(res) {
              console.log('reqeust completed')
            }
          })
        } else {
          wx.showToast({
            title: '发起支付失败',
            icon: 'none'
          })
        }
      }
    })
  },
  //该方法用于支付成功后重新分配金额
  redistributeMoney: function(wechat) {
    //开始发送
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/redistributeCommission
      url: 'https://www.pinoteacher.com/admin/Respond/redistributeCommission',
      data: {
        moneyAmount: this.data.moneyAmount,
        wechat: wechat,
        invitationCode: this.data.invitationCode
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        console.log(res.data)
      },
      fail: function() {
        console.log('fail')
      },
      complete: function() {}
    })
  },
  saveOrder: function(contact) {
    //开始发送
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/saveOrder
      url: 'https://www.pinoteacher.com/admin/Respond/saveOrder',
      data: {
        total_money: this.data.moneyAmount,
        server: this.data.teacherInfo['username'],
        wechat: contact,
        payer: this.data.orderName,
        payerPhone: this.data.orderPhone,
        create_time: this.data.date + ' ' + this.data.time,
        commodity: this.data.teacherInfo['can_solve']
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        console.log(res.data)
      },
      fail: function() {
        console.log('fail')
      },
      complete: function() {}
    })

  }
})