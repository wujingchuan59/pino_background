// query/query.js
Page({
//记录用户输入的内容
oninput:function(e){
  this.setData({
    queryInfo: e.detail.value
  })
},
  /**
   * 页面的初始数据
   */
  data: {
    queryInfo : '',
    orderInfo:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //设置导航条颜色
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: '#3988FB',
    }),
      //设置导航条标题
      wx.setNavigationBarTitle({
        title: '订单查询',
      })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  //用户点击"查询"按钮触发查询订单功能
  query: function (e) {
    //传递值
    var that = this
    //获得当前输入的内容
    var userInfo = this.data.queryInfo
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/queryOrder
      url: 'https://www.pinoteacher.com/admin/Respond/queryOrder',
      data: {
        userInfo: userInfo
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function (res) {
        //绑定值
        if(res.data['status'] == 1){
          that.setData({
            orderInfo: res.data['orderInfo']
          })
        }else{
          wx.showToast({
            title: '查询订单失败',
            icon:'none'
          })
        }
        console.log(res.data['orderInfo'])
      },
      fail: function () {
        console.log('fail')
      },
      complete: function () {
      }
    })
  }
})

