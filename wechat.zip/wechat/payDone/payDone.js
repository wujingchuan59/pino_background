// payDone/payDone.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //设置导航条颜色
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: '#3988FB',
    })
    //设置导航条标题
    wx.setNavigationBarTitle({
      title: '支付成功',
    })
    //获取数据:支付的数额，以及收款方联系方式
    var money_amout = wx.getStorageSync('money-amout')
    var contact = wx.getStorageSync('sever-contact')
    var payDate = wx.getStorageSync('pay_date')
    var payTime = wx.getStorageSync('pay_time')
    //设置值
    this.setData({
      money:money_amout,
      server:contact,
      payDate:payDate,
      payTime:payTime
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  /**
   * 用户点击完成按钮开始
   */
  complete:function(){
    wx.showModal({
      title: '提示',
      content: '建议您将此页面截图',
      cancelText: '去截图',
      cancelColor: '#3988FB',//取消文字的颜色
      confirmText: '已截图',
      confirmColor: '#3988FB',//确定文字的颜色
      success:function(res){
        if(res.confirm){
          wx.redirectTo({
            url: '../pino/pino',
          })
        }
      },
    })

  }
})