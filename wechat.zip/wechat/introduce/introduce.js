// introduce/introduce.js
Page({
  //记录用户输入内容
  username: function(e) {
    this.setData({
      username: e.detail.value
    })
  },
  phone: function(e) {
    this.setData({
      phone: e.detail.value
    })
  },
  code: function(e) {
    this.setData({
      code: e.detail.value
    })
  },
  //用户注册按钮
  register: function() {
    //检查用户数据
    var username = this.data.username
    var phone = this.data.phone
    var code = this.data.code
    //首先检查名字
    if (username.length == 0) {
      wx.showToast({
        title: '名字不能为空',
        icon: 'none'
      })
      //返回程序
      return
    }
    //检查电话是否为11
    if (phone.length != 11) {
      wx.showToast({
        title: '手机号有误',
        icon: 'none'
      })
      //返回程序
      return
    }
    //检查邀请码
    if (code.length == 0) {
      wx.showToast({
        title: '邀请码有误',
        icon: 'none'
      })
      //返回程序
      return
    }
    //开始注册
    this.sendData()
  },
  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    phone: '',
    code: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //设置导航条颜色
    wx.setNavigationBarColor({
        frontColor: '#ffffff',
        backgroundColor: '#3988FB',
      }),
      //设置导航条标题
      wx.setNavigationBarTitle({
        title: '成为推荐者',
      })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //用于发送用户
  sendData: function() {
    //保证用户输入值不为空
    var jsonData = JSON.stringify(this.data.username)
    var that = this
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/registerIntroduce
      url: 'https://www.pinoteacher.com/admin/Respond/registerIntroduce',
      data: {
        username: decodeURIComponent(jsonData),
        phone: this.data.phone,
        code: this.data.code
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        //绑定值
        if (res.data != 0) {
          //获取返回数据
          var result = res.data
          //获取状态码
          var status = result['status']
          //获取状态信息
          var message = result['message']
          console.log(result)
          if (status == -1) {
            wx.showToast({
              title: '加入失败',
              icon: 'none'
            })
            //返回主程序
            return
          } else if (status == 0) {
            wx.showToast({
              title: '邀请码错误',
              icon: 'none'
            })
            //返回主程序
            return
          } else if (status == -2) {
            wx.showToast({
              title: '推荐者已满员',
              icon: 'none'
            })
            //返回主程序
            return
          } else if (status == -3) {
            wx.showToast({
              title: '该手机已注册',
              icon: 'none'
            })
            //返回主程序
            return
          }
          if (status == 1) {
            wx.showModal({
              title: '您的邀请码',
              content: result['invitation_code'],
              confirmText: '记住了',
              confirmColor: '#3988FB', //确定文字的颜色
              success: function(res) {
                //如果点击确定则返回主页面
                if (res.confirm) {
                  wx.navigateBack({
                    complete: function() {
                      wx.showToast({
                        title: '加入成功',
                      })
                    }
                  })
                }
              }
            })
          }
        }
      },
      fail: function() {
        console.log('fail')
      },
      complete: function() {}
    })

  }
})