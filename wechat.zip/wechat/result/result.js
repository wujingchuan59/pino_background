// result/result.js
Page({
  copyPhone: function(e) {
    //获取点击内容id
    var elementId = e.target.id
    //去除冗余文字
    var id = elementId.replace('phone_', '')
    //根据id找到对应内容值
    var teacherInfoArray = this.data.teacherInfo
    var teacherInfo = teacherInfoArray[id]
    //设置剪切板
    var phone = teacherInfo['phone'];
    //如果电话有值
    if (phone != '暂无') {
      //将信息复制到剪切板
      wx.setClipboardData({
        data: phone
      })
      //将信息发送到数据库
      var copied = this.data.originalTeacherInfo[id];
      var param = phone + '&' + copied['can_solve']
      this.sendCopied(param)
    }
  },

  copyWechat: function(e) {
    //获取点击内容id
    var elementId = e.target.id
    //去除冗余文字
    var id = elementId.replace('wechat_', '')
    //根据id找到对应内容值
    var teacherInfoArray = this.data.teacherInfo
    var teacherInfo = teacherInfoArray[id]
    //设置剪切板
    var wechat = teacherInfo['wechat'];
    //如果电话有值
    if (wechat != '暂无') {
      wx.setClipboardData({
        data: wechat
      })
      //将信息发送到数据库
      var copied = this.data.originalTeacherInfo[id];
      var param = wechat + '&' + copied['can_solve']
      this.sendCopied(param)
    }
  },
  copyTap: function(e) {
    //获取点击内容id
    var elementId = e.target.id
    //去除冗余文字
    var id = elementId.replace('copy_', '')
    //根据id找到对应内容值
    var teacherInfoArray = this.data.teacherInfo
    var teacherInfo = teacherInfoArray[id]
    //设置剪切板
    var phoneOrWechat = '';
    if (teacherInfo['phone'] != '暂无') {
      phoneOrWechat = teacherInfo['phone'];
    } else if (teacherInfo['wechat'] != '暂无') {
      phoneOrWechat = teacherInfo['wechat']
    }
    //开始提示用户选择需要的联系方式
    wx.showModal({
      title: '',
      content: '选择您需要的联系方式',
      cancelText: '微信',
      cancelColor: '#3988FB', //取消文字的颜色
      confirmText: '电话',
      confirmColor: '#3988FB', //确定文字的颜色
      success: function(res) {
        if (res.cancel) {
          //点击微信，则将微信联系方式复制到剪切板
          //提示用户复制到剪切板成功
          wx.setClipboardData({
            data: phoneOrWechat,
            success(res) {
              wx.showToast({
                title: "已复制到剪切板",
              })
              setTimeout(function() {
                wx.showToast({
                  title: '请添加微信联系',
                })
              }, 1000)
            }
          })
        } else {
          //点击电话，则将电话联系方式进行复制
          //提示用户复制到剪切板成功
          wx.setClipboardData({
            data: phoneOrWechat,
            success(res) {
              wx.showToast({
                title: "已复制到剪切板",
              })
              setTimeout(function() {
                wx.showToast({
                  title: '请添加电话联系',
                })
              }, 1000)
            }
          })
        }
      },
      fail: function(res) {}, //接口调用失败的回调函数
      complete: function(res) {}, //接口调用结束的回调函数（调用成功、失败都会执行）
    })

    //将信息发送到数据库
    var copied = this.data.originalTeacherInfo[id];
    var param = phoneOrWechat + '&' + copied['can_solve']
    this.sendCopied(param)
  },
  tapToDetail: function(e) {
    //获取点击内容id，存储内容然后开始跳转
    var elementId = e.target.id
    //去除冗余文字
    var id = elementId.replace('content_', '')
    //根据id找到对应内容值
    var teacherInfoArray = this.data.teacherInfo
    var teacherInfo = teacherInfoArray[id]
    //存储值
    wx.setStorage({
      key: 'user-detail',
      data: teacherInfo,
    })
    //如果用户点击进入详细内容
    wx.navigateTo({
      url: '../detail/detail',
    })
  },
  payTap: function(e) {
    //根据点击获得元素id
    var elementId = e.target.id
    //去除冗余文字
    var id = elementId.replace('pay_', '')
    //根据id找到对应iphone或者wechat
    var teacherInfoArray = this.data.originalTeacherInfo
    var teacherInfo = teacherInfoArray[id]
    //1.将用户信息存储进入临时空间
    wx.setStorage({
      key: 'teacherInfo_Pay',
      data: teacherInfo,
    })
    //2.提示用户免责信息
    wx.showModal({
      title: '免责声明',
      content: '服务全部由第三方提供，PINO搜索不承担任何责任',
      cancelText: '取消',
      cancelColor: '#3988FB', //取消文字的颜色
      confirmText: '继续支付',
      confirmColor: '#3988FB', //确定文字的颜色
      success: function(res) {
        //如果点击确定则进入搜索页面
        if (res.confirm) {
          //跳转到支付页面
          wx.navigateTo({
            url: '../pay/pay',
          })
        }
      }
    })

  },
  //点赞数
  likeTap: function(e) {
    //根据点击获得元素id
    var elementId = e.target.id
    //去除冗余文字
    var id = elementId.replace('like_', '')
    //根据id找到对应wechat值
    var teacherInfoArray = this.data.teacherInfo
    var teacherInfo = teacherInfoArray[id]
    //根据手机号，判断用户联系方式
    if (teacherInfo['phone'] != '暂无') {
      //如果手机号不为空，则返回手机号
      this.sendLike(teacherInfo['phone'])
    } else {
      //如果微信号不为空，则返回微信号
      this.sendLike(teacherInfo['wechat'])
    }

  },
  //点击按钮弹出指定的hiddenmodalput弹出框
  remarkinput: function(e) {
    this.setData({
      remark: e.detail.value
    })
  },
  remark: function(e) {
    //根据点击获得元素id
    var elementId = e.target.id;
    //去除冗余文字
    var id = elementId.replace('remark_', '')
    //根据id找到对应的wechat值
    var teacherInfoArray = this.data.teacherInfo
    var teacherInfo = teacherInfoArray[id]
    //根据手机号，判断用户联系方式
    if (teacherInfo['phone'] != '暂无') {
      //如果手机号不为空，则存储手机号
      this.setData({
        remarkId: teacherInfo['phone'],
      })
    } else {
      //如果微信号不为空，则存储微信号
      this.setData({
        remarkId: teacherInfo['wechat'],
      })
    }
    //存储被评价人数据
    wx.setStorage({
      key: 'remarkId',
      data: this.data.remarkId,
    })
    //转到评价模块
    wx.navigateTo({
      url: '../remark/remark',
    })
  },

  //text输入事件(用于搜索框输入内容))
  bindInput: function(e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  //PINO搜索label点击返回主页面
  returnMain: function() {
    wx.redirectTo({
      url: '../pino/pino',
    })
  },

  //当前页面点击PINO按钮事件
  pino: function() {
    //获得用户输入值
    var searchData = this.data.inputValue
    if (searchData.length != 0) {
      //开始设置搜索值
      wx.setStorage({
        key: 'searchData',
        data: searchData,
      })
      //开始重新载入
      wx.redirectTo({
        url: '../result/result',
      })
    } else {
      wx.showToast({
        title: '没有内容哦~',
      })
    }
  },
  /**
   * 页面的初始数据
   */
  data: {
    originalTeacherInfo: '',
    teacherInfo: '',
    count: 0,
    inputValue: '',
    searchValue: wx.getStorageSync('searchData'),
    teacherInfos: [0, 1, 3, 4],
    color: "red",
    remark: ''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //设置导航条颜色
    wx.setNavigationBarColor({
        frontColor: '#ffffff',
        backgroundColor: '#3988FB',
      }),
      //设置导航条标题
      wx.setNavigationBarTitle({
        title: '搜索结果',
      })
    //获得数据
    var searchData = wx.getStorageSync('searchData')
    if (searchData != '') {
      //开始进行搜索
      this.search(searchData)
    }
    //提示加
    wx.showToast({
      title: '加载中...',
      mask: true,
      icon: 'loading'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    //设置显示值
    this.setData({
      searchValue: wx.getStorageSync('searchData')
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  sendLike: function(id) {
    //保证用户输入值不为空
    var jsonData = JSON.stringify(id)
    var that = this
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/likeWXRequest
      url: 'https://www.pinoteacher.com/admin/Respond/likeWXRequest',
      data: {
        like: decodeURIComponent(jsonData)
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        //绑定值
        if (res.data != 0) {
          wx.showToast({
            title: '点赞成功',
          })
        } else {
          wx.showToast({
            title: '点赞失败',
          })
        }
      },
      fail: function() {
        console.log('fail')
      },
      complete: function() {}
    })
  },
  search: function(message) {
    //保证用户输入值不为空
    var jsonData = JSON.stringify(message)
    var that = this
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/searchWXRequest
      url: 'https://www.pinoteacher.com/admin/Respond/searchWXRequest',
      data: {
        search: decodeURIComponent(jsonData)
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        //绑定值
        if (res.data != 0) {
          //获得数据并将数据转化成带有关键字加红的内容
          var searchingData = wx.getStorageSync("searchData").toLowerCase();
          var teacherInfo = res.data["teacherInfo"]
          //将现在的值赋值给一个起始值用于他用
          that.setData({
            originalTeacherInfo: teacherInfo
          })
          var reddenCanSolve = []
          //teacherInfo是存储了全部解决问题条目
          for (var i = 0; i < teacherInfo.length; i++) {
            var can_solve = teacherInfo[i]['can_solve']
            var tempCanSolve = []
            for (var j = 0; j < can_solve.length; j++) {
              //如果该字符属于查询字符
              var loweredCan_solve = can_solve[j].toLowerCase();
              if (searchingData.indexOf(loweredCan_solve) > -1) {
                tempCanSolve.push({
                  "content": can_solve[j],
                  "value": true
                })
              } else {
                tempCanSolve.push({
                  "content": can_solve[j],
                  "value": false
                })
              }
            }
            //将值整理成数组放入teacherInfo
            teacherInfo[i]["can_solve"] = tempCanSolve
            //将手机或微信部分字符转变成隐藏字符：*
            var phone = teacherInfo[i]["phone"]
            var wechat = teacherInfo[i]["wechat"]
            var obscuredPhone = ""
            var obscuredWechat = ""
            if (phone != "暂无") {
              obscuredPhone = "*******" + phone.substring(phone.length - 4, phone.length)
            } else {
              obscuredPhone = "暂无"
            }
            if (wechat != "暂无") {
              if (wechat.length >= 2) {
                obscuredWechat = "********" + wechat.substring(wechat.length - 2, wechat.length)
              } else {
                obscuredWechat = "********" + wechat.substring(wechat.length - 1, wechat.length)
              }
            } else {
              obscuredWechat = "暂无"
            }
            //将隐藏了数值的联系联系方式加入数组
            teacherInfo[i]["obscuredPhone"] = obscuredPhone
            teacherInfo[i]["obscuredWechat"] = obscuredWechat
            //将is_official数值从数组变成binary
            var is_official = teacherInfo[i]["is_official"]
            if (is_official == 1) {
              teacherInfo[i]["is_official"] = true
            } else if (is_official == 0) {
              teacherInfo[i]["is_official"] = false
            }
          }
          //绑定数值
          that.setData({
            teacherInfo: res.data["teacherInfo"],
            count: res.data["teacherInfo"].length,
            can_solve: reddenCanSolve
          })
        } else {
          wx.showToast({
            title: '没有找到~',
            icon: 'none'
          })
        }
      },
      fail: function() {
        //提示用户网络问题
        wx.showToast({
          title: '额，网络有点问题',
          icon: 'none'
        })
      },
      complete: function() {}
    })
  },
  //记录哪些客户的联系方式被复制了
  sendCopied: function(copied) {
    //获得用户id和可以解决的问题
    var jsonData = JSON.stringify(copied)
    var that = this
    //开始连接服务器发送值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/registerWXCopied
      //http://pinoteacher.com//admin/Respond/registerWXCopied
      url: 'https://www.pinoteacher.com/admin/Respond/registerWXCopied',
      data: {
        copied: jsonData
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        //绑定值
        if (res.data != 0) {}
      },
      fail: function() {
        console.log('fail')
      },
      complete: function() {}
    })
  }
})