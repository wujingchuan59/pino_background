// remark/remark.js
Page({
  //按钮点击事件
  //点击好评事件
  perfectTap: function(e) {
    this.setData({
      perfect: 'perfect.png',
      inferior: 'inferior-gray.png',
      isPerfect: '1'
    })
  },
  //点击差评事件
  inferiorTap: function(e) {
    this.setData({
      perfect: 'perfect-gray.png',
      inferior: 'inferior.png',
      isPerfect: '0'
    })
  },
  //评价术语
  remark: function(e) {
    this.setData({
      remark: e.detail.value
    })
  },
  //点击发布评价
  sendRemark: function(e) {
    //首先保证评价内容不为空且默认好评、
    if(this.data.remark.length != 0 && this.remark != ' '){
      //开始连接服务器进行评价
      this.sendData()
    }else{
      //如果用户评价内容为空则提示用户还没输入评价内容
      wx.showToast({
        title: '还没输入内容哦',
        icon:'none'
      })
    }
  },
  /**
   * 页面的初始数据
   */
  data: {
    perfect: 'perfect-gray.png',
    inferior: 'inferior-gray.png',
    remark: '',
    remarkId:'',
    isPerfect: '1'
  },
  //用于发送用户评价
  sendData:function(){
    //保证用户输入值不为空
    var jsonData = JSON.stringify(this.data.remark)
    var that = this
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/remarkWXRequest
      url: 'https://www.pinoteacher.com/admin/Respond/remarkWXRequest',
      data: {
        remark: decodeURIComponent(jsonData),
        remarkId: this.data.remarkId,
        isPerfect:this.data.isPerfect
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function (res) {
        //绑定值
        if (res.data != 0) {
          wx.navigateBack({
            complete:function(){
              wx.showToast({
                title: '评价成功',
              })
            }
          })
        } else {
          wx.showToast({
            title: '评价失败',
          })
        }
      },
      fail: function () {
        console.log('fail')
      },
      complete: function () { }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //接收数据
    var remarkId = wx.getStorageSync('remarkId')
    //设置值
    this.setData({
      remarkId:remarkId
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    //设置导航条颜色
    wx.setNavigationBarColor({
        frontColor: '#ffffff',
        backgroundColor: '#3988FB',
      }),
      //设置导航条标题
      wx.setNavigationBarTitle({
        title: '发表评价',
      })

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})