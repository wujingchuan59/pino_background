// register/register.js
Page({
  beIntroducer:function(){
    wx.navigateTo({
      url: '../introduce/introduce',
    })
  },
  //以下是信息输入模块
  directToPino: function() {
    wx.navigateBack({})
  },
  username: function(e) {
    this.setData({
      username: e.detail.value
    })
  },
  wechat: function(e) {
    this.setData({
      wechat: e.detail.value
    })
  },
  can_solve: function(e) {
    this.setData({
      can_solve: e.detail.value
    })
  },
  //开始进行注册按钮
  register: function(e) {
    if ((this.data.username.length == 0) ||
      (this.data.wechat.length == 0) ||
      (this.data.can_solve.length == 0)) {
      wx.showToast({
        title: '信息不完整哦',
        icon: 'none'
      })
    } else {
      //开始更新用户数据
      this.updateUserInfo();
    }
  },
  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    wechat: '',
    can_solve: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //设置导航条颜色
    wx.setNavigationBarColor({
        frontColor: '#ffffff',
        backgroundColor: '#3988FB',
      }),
      //设置导航条标题
      wx.setNavigationBarTitle({
        title: '用户注册',
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  //发送信息
  updateUserInfo: function() {
    //传递this
    var that = this
    //整理数据
    var userInfoString = this.data.username + "&&" + this.data.wechat + "&&" + this.data.can_solve
    //开始连接服务器查询值
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/updateWXUser
      url: 'https://www.pinoteacher.com/admin/Respond/updateWXUser',
      data: {
        userInfo: userInfoString
      },
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function(res) {
        //绑定值
        if (res.data.length != 0) {
          var data = res.data
          console.log(data['message'])
          if (data['status'] == 0) {
            wx.showToast({
              title: '注册失败',
              message: data['message']
            })
          } else if (data['status'] == 1) {
            wx.navigateBack({
              complete: function() {
                wx.showToast({
                  title: '注册成功',
                })
              }
            })
          } else if (data['status'] == 2) {
            wx.navigateBack({
              complete: function() {
                wx.showToast({
                  title: '更新成功',
                })
              }
            })
          }
        } else {
          wx.showToast({
            title: '获取信息失败',
          })
        }
      },
      fail: function() {
        console.log('fail')
      },
      complete: function() {}
    })
  },
})