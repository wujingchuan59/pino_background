// pages/pino.js
Page({
  //搜索框获得焦点
  searchTyping:function(e){
    this.setData({
      boxshadow: "0px 2px 6px 0px #000000",
    })
  },
  //搜索框失去焦点
  searchBlur:function(e){
    this.setData({
      boxshadow: "none",
    })
  },
  //注册事件
  registerTap:function(e){
    wx.navigateTo({
      url: '../register/register',
    })
  },
  //输入框输入事件
  bindInput:function(e){
    this.setData({
      inputValue:e.detail.value
    })
  },
  //点击事件：
  onTap:function(){
    //获得用户输入值
    var searchValue = this.data.inputValue
    //保证用户输入值不为空
    if (searchValue.length != 0) {
      wx.setStorage({
        key: 'searchData',
        data: searchValue,
      })
      wx.navigateTo({
        url: '../result/result',
      })
    } else {
      //TODO:提示用户需要输入
      wx.showToast({
        title: '没有内容哦~',
        icon:'none'
      })
    }
  },
  /**
   * 页面的初始数据
   */
  data: {
    inputValue:'',
    searched1:'',
    searched2:'',
    searched3:'',
    searchBorderColor:"gray"
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //获取广告
    var that = this
    wx.request({
      //网址：https://www.pinoteacher.com/admin/Respond/getWXAdvertise
      url: 'https://www.pinoteacher.com/admin/Respond/getWXAdvertise',
      header: {
        //设置参数内容类型为x-www-form-urlencoded
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      method: "POST",
      success: function (res) {
        //绑定值
        if (res.data != 0) {
          //随机获得数据并绑定值
          var data = res.data['advertise']
          that.setData({
            searched1: data[0]['title'],
            searched2: data[1]['title'],
            searched3: data[2]['title'],
          })
        } else {
        }
      },
      fail: function () {
        //提示用户网络问题
        wx.showToast({
          title: '额，网络有点问题',
          icon: 'none'
        })
      },
      complete: function () {
      }
    })  
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 用户点击查询按钮，导航到查询页面
   */
  queryTap:function(e){
    wx.navigateTo({
      url: '../query/query',
    })
  }
})