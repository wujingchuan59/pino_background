// detail/detail.js
Page({
  //当用户点击 赞 时候提示用户点击成功
  liketap:function(e){
    wx.showToast({
      title: '点赞成功',
    })
  },
  //
  copyPhone:function(e){
    var user_info = this.data.user_detail;
    var phone = user_info['phone'];
    if(phone != '暂无'){
      wx.setClipboardData({
        data: phone,
      })
    }
  },
  copyWechat:function(e){
    var user_info = this.data.user_detail;
    var wechat = user_info['wechat'];
    if (wechat != '暂无') {
      wx.setClipboardData({
        data: wechat,
      })
    }
  },
  /**
   * 页面的初始数据
   */
  data: {
     user_detail : ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //设置导航条
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: '#3988FB',
    })
    //获得传递的消息
    var teacherInfo = wx.getStorageSync('user-detail')
    //赋值
    this.setData({
      user_detail:teacherInfo
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})