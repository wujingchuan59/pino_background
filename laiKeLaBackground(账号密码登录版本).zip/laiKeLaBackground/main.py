
# 引入需要的包以及获得系统路径
import os
import sys

from scrapy.cmdline import execute

# 获得当前文件的路径
path = sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 开始执行文件
execute(["scrapy", "crawl", "qqgroup"])
