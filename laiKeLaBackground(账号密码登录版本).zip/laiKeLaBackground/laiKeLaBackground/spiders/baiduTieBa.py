# -*- coding: utf-8 -*-
import scrapy
import requests
import json
import re

# re模块使得你能够获得
class BaidutiebaSpider(scrapy.Spider):
    name = 'baiduTieBa'
    allowed_domains = ['https://tieba.baidu.com/']

    # 设置url,用于从来客啦数据库获取需要检索的关键词
    url = 'https://www.pinoteacher.com/admin/Respond/scrapingHubReceiveData'
    # 开始链接来客啦后台获得数据
    result = requests.get(url)
    # json分解数据，获得全部的需要检索的数据
    resultArray = json.loads(result.content)
    keywordArray = []
    # 将数据整理成数组
    start_urls = []
    for query in resultArray:
        url = 'http://tieba.baidu.com/f?ie=utf-8&kw=' + query['query_type'] + '&fr=search'
        # 将关键字存储进入数组以便使用
        keywordArray.append(query['query_type'])
        # 将新生成的url存储进入数组
        start_urls.append(url)
    pass

    # 正则表达式测试
    line = r"想去美国留学，谁知道那个机构好"
    source_pattern = r""

    def parse(self, response):
        post_nodes = response.css(".j_th_tit a::attr(title)").extract()
        available_arrays = []
        if post_nodes:  # 将获取到的数据发送给php服务器并在服务器端存储数据，然后通知用户
            for item in post_nodes:
                # 开始进行正则表达式的匹配
                regex_str = ".*谁.*|.*哪家.*|.*问.*|.*请问.*|.*吗.*|.*求.*|.*问题.*|.*怎么样.*|.*求.*|.*谁知道.*|.*求帮助.*|.*好吗.*"
                match_obj = re.match(regex_str, item)
                if match_obj:
                    available_arrays.append(match_obj.group(0))
        # 发送数据给客户，用于实现数据的接收
        if len(available_arrays) > 0:
            self.sendData(available_arrays)
    pass

    def sendData(self, data):
        if len(data) > 0:
            url = "https://www.pinoteacher.com/admin/Respond/receiveScrapyData"
            values = {
                'data': data
            }
            headers = {'content-type': 'charset=utf8'}
            print(data)
            res = requests.post(url, data=json.dumps(values).encode('utf-8'), headers=headers)
            print(res)
    pass



















